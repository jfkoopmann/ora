#-- Need to set Dfile.encoding=UTF-8 is set in the JVR arguments
cuttyhunk sync

| => grep -i javaopts *.json
PegaAppTier.json:    "name" : "JavaOpts",
PegaStreamTier.json:    "name" : "JavaOpts",
PegaUtilTier.json:    "name" : "JavaOpts",

  }, {
    "name" : "JavaOpts",
    "value" : "-Xms8192m -Xmx8192m -XX:+HeapDumpOnOutOfMemoryError -verbose:gc -XX:+UseGCLogFileRotation -XX:NumberOfGCLogFiles=3  -XX:GCLogFileSize=2M -Xloggc:/usr/local/tomcat/logs/gc.log -XX:+PrintGCDateStamps -XX:+PrintGCDetails  -XX:+DisableExplicitGC -XX:ReservedCodeCacheSize=512m -XX:MetaspaceSize=512m -XX:+UseG1GC -XX:+PrintHeapAtGC -Dcom.sun.xml.bind.v2.bytecode.ClassTailor.noOptimize=true -XX:+UseMembar -Dfile.encoding=UTF-8",
    "upgradeValue" : null,
    "encrypted" : false
  }, {

| => grep -i dfile *.json
PegaAppTier.json:    "value" : "-Xms8192m -Xmx8192m -XX:+HeapDumpOnOutOfMemoryError -verbose:gc -XX:+UseGCLogFileRotation -XX:NumberOfGCLogFiles=3 -XX:GCLogFileSize=2M -Xloggc:/usr/local/tomcat/logs/gc.log -XX:+PrintGCDateStamps -XX:+PrintGCDetails -XX:+DisableExplicitGC -XX:+PrintCodeCache -XX:ReservedCodeCacheSize=512m -XX:MetaspaceSize=512m -XX:MaxMetaspaceSize=1536m -XX:+UseG1GC -Dfile.encoding=UTF-8",
PegaStreamTier.json:    "value" : "-Xms10240m -Xmx10240m -XX:+HeapDumpOnOutOfMemoryError -verbose:gc -XX:+UseGCLogFileRotation -XX:NumberOfGCLogFiles=3 -XX:GCLogFileSize=2M -Xloggc:/usr/local/tomcat/logs/gc.log -XX:+PrintGCDateStamps -XX:+PrintGCDetails -XX:+DisableExplicitGC -XX:+PrintCodeCache -XX:ReservedCodeCacheSize=512m -XX:MetaspaceSize=512m -XX:MaxMetaspaceSize=1536m -XX:+UseG1GC -Dfile.encoding=UTF-8",
PegaUtilTier.json:    "value" : "-Xms8192m -Xmx8192m -XX:+HeapDumpOnOutOfMemoryError -verbose:gc -XX:+UseGCLogFileRotation -XX:NumberOfGCLogFiles=3 -XX:GCLogFileSize=2M -Xloggc:/usr/local/tomcat/logs/gc.log -XX:+PrintGCDateStamps -XX:+PrintGCDetails -XX:+DisableExplicitGC -XX:+PrintCodeCache -XX:ReservedCodeCacheSize=512m -XX:MetaspaceSize=512m -XX:MaxMetaspaceSize=1536m -XX:+UseG1GC -Dfile.encoding=UTF-8",

cuttyhunk provision-node .


#---
PEGA0104 Background process blocked due to exhausted thread pool.
Root Cause
/ROOT/PEGACLOUD/NIKE/CR32777/BAM/us-west-1/PROD/prod1 >* a PegaAppTier
# ID State Public Ip Private Ip Avail. Zone Launch Time
0 i-05fec69d8fc031088 running 184.72.29.233 10.184.242.9 us-west-1a 2022-02-04 00:16:19+00:00
1 i-044da1fa99c4c8607 running 54.219.242.137 10.184.242.20 us-west-1a 2022-02-04 00:24:39+00:00
2 i-0f524c3c4a0bf0309 running 52.8.237.134 10.184.242.42 us-west-1c 2022-02-04 00:42:17+00:00
3 i-02f6fac0b6a24ebc7 running 52.8.63.19 10.184.242.60 us-west-1c 2022-02-04 00:33:19+00:00
/ROOT/PEGACLOUD/NIKE/CR32777/BAM/us-west-1/PROD/prod1 [PegaAppTier] >* run 2 pega-ping
. .

200

/ROOT/PEGACLOUD/NIKE/CR
Additional Notes
recurring alert


#---
PEGA0114 Offline partitions in broker
Root Cause
restart of util nodes

#---
/singleton
resize2fs /dev/xvdg (device being used)

#---
PC002 alert, logstash container is consuming high CPU.
Kentdrick Barnes 9:14 AM
I have a PC002 alert, logstash container is consuming high CPU. Should I raise a ticket for this issue or restart the node?
Christopher Dahlstedt 9:23 AM
If its a pattern Kentdrick then its most likely related to the undersized ELK node.  If its just a one-off just restart the ELK node for now
Kentdrick Barnes 9:23 AM
This has been going on for 3 days atleast
Christopher Dahlstedt 9:23 AM
Use CC-144772 as an example
Kentdrick Barnes 9:24 AM
Got it thanks
Christopher Dahlstedt 9:24 AM
yeah then check the instance type of the ELK node and if its a T2 or T3 upsize it according to the ELK doc, should be able to do all of it via the GOC
Kentdrick Barnes 9:29 AM
m5.large
Christopher Dahlstedt 9:32 AM
check if the JVM arguments are there as well
Christopher Dahlstedt 9:32 AM
-Xmx3g 
Christopher Dahlstedt 9:34 AM
If they are and there are no JVM alerts then this is a logstash issue/bug, I would check knowledge base to see if there is a fix or maybe its their version of Cloud.  Ask the team in the chat, Praba or Saheb might be up to date with that info as well

#---
#--- customer specific
PC031 : Production : ausdha-permit-prod1 : elk-server : Multiple node terminations (1hour) : 3 or more Nodes terminated in hour
(AL-64245)
Environment Path
/ROOT/PEGACLOUD/AUSDHA/CR69388/PERMIT/ap-southeast-2/PROD1/prod2
Environment name
ausdha-permit-prod1
Australian Department of Home Affairs
(AUSDHA)
(INC-216132)
Continuous errors in logs/PDC causing Kibana node failure
Description
Team our 24x7 Cloud SRT monitoring system has alerted us to repeated failures of the Kibana node for this environment. Upon an initial review of your 
PegaRULES.logs we are seeing the following consistent errors and also your PDC is showing a large amount of PEGA0005 and PEGA0011 events which seem to 
be overwhelming the Kibana node and causing it to fail repeatedly. We advise that you review your environment to try and remediate these issues. If you 
need assistance I have opened this ticket with our GCS/product team to try and assist you.
PDC event viewer
high PEGA0005 - DB-Time (48999)
high PEGA0011 - Service Total Time (431)
PDC Improvement Plan
high "Slow report GetSubCaseStatuses" (310h 14m)

#---
#--- OOM and High Active Thread Count
q: If a client is experiencing OOM and High active Thread count alerts consistently. Is it wise to request that they increase their instance size?
a: Need to check for existing tickets that might be investigating, then if not, Heap and Thread Dumps should be collected along with any related PD 
   data and a INC opened with the client to see if they can resolve on their own.  If they need our assistance we can involve a DBA if its SQL 
   related or it would then be transferred to product
   I would offer to walk you through it today but I am working on FR stuff.  I would start with looking for existing tickets and if not then definitely 
  collect Thread and Heaps from the GOC, assuming this is Commercial

