============== Query for index usage :
SELECT relid::regclass AS table, indexrelid::regclass AS index,
pg_size_pretty(pg_relation_size(indexrelid::regclass)) AS index_size,
idx_tup_read, idx_tup_fetch, idx_scan FROM pg_stat_user_indexes JOIN pg_index USING (indexrelid)
WHERE relname='cpmhc_quest_fw_adtfw_work';

idx_scan      - Number of index scans initiated on this index
idx_tup_read  - Number of index entries returned by scans on this index
idx_tup_fetch - Number of live table rows fetched by simple index scans using this index

-- Simplified version.

SELECT s.relname AS table_name, Schemaname, indexrelname AS index_name, i.indisunique, idx_scan AS index_scans
FROM pg_catalog.pg_stat_user_indexes s, pg_index i WHERE i.indexrelid = s.indexrelid and s.relname='cpmhc_quest_fw_adtfw_work';
