\set AUTOCOMMIT off
\echo :AUTOCOMMIT

SELECT CURRENT_TIMESTAMP ;

--# 
\l        , list databases
\c dbname , connect to database
\dn       , list schemas
SHOW maintenance_work_mem;
SET maintenance_work_mem to '10MB';

--# table size
select pg_relation_size('pegadata.safs_tyfs_fw_sales_work_contac');
select pg_relation_size('pegadata.safs_tyfs_fw_sales_work_contac')/1024/1024 as "size_MB";

--# list extensions
select * FROM pg_extension;

--#sync
cuttyhunk sync --path CMDB --no-encrypt --silent

aws s3 cp s3://cuttyhunk-prod-data-bucket-ca-central-1/CIBC-CR56564-NAVIG/Production/cibc-srvc-pte1/cloud-bundles/custom-cloud-bundle.tar .

--# find RDS instance
cuttysh.py
cd <CMDB path>
grep DatabaseHost RDSDatabase

_Q.vU3NUs3W8CBd6
Subjectivization

