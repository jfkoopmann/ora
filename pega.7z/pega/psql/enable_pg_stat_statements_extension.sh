--# enable the pg_stat_statements extension for collecting query statistics

https://pganalyze.com/docs/install/amazon_rds/01_configure_rds_instance

pega=> \dx
                 List of installed extensions
  Name   | Version |   Schema   |         Description
---------+---------+------------+------------------------------
 plpgsql | 1.0     | pg_catalog | PL/pgSQL procedural language
(1 row)

pega=> SELECT * FROM pg_extension;
  oid  | extname | extowner | extnamespace | extrelocatable | extversion | extconfig | extcondition
-------+---------+----------+--------------+----------------+------------+-----------+--------------
 14359 | plpgsql |       10 |           11 | f              | 1.0        |           |
(1 row)

pega=> CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;
CREATE EXTENSION
pega=>
pega=> CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;
NOTICE:  extension "pg_stat_statements" already exists, skipping
CREATE EXTENSION

pega=> SELECT * FROM pg_stat_statements LIMIT 1;
 userid | dbid  |       queryid        |            query             | calls |      total_time       | min_time | max_time | mean_time |      stddev_time      | rows | shared_blks_hit | shared_blks_read | shared_blks_dirtied | shared_blks_written | local_blks_hit | local_blks_read | local_blks_dirtied | local_blks_written | temp_blks_read | temp_blks_written | blk_read_time | blk_write_time
--------+-------+----------------------+------------------------------+-------+-----------------------+----------+----------+-----------+-----------------------+------+-----------------+------------------+---------------------+---------------------+----------------+-----------------+--------------------+--------------------+----------------+-------------------+---------------+----------------
  16394 | 16396 | -7937358851754477637 | SAVEPOINT JDBC_SAVEPOINT_818 |     6 | 0.0029159999999999998 | 0.000373 |  0.00057 |  0.000486 | 6.288349014911093e-05 |    0 |               0 |                0 |                   0 |                   0 |              0 |               0 |                  0 |                  0 |              0 |                 0 |             0 |              0
(1 row)

pega=> \dx
                                     List of installed extensions
        Name        | Version |   Schema   |                        Description
--------------------+---------+------------+-----------------------------------------------------------
 pg_stat_statements | 1.7     | public     | track execution statistics of all SQL statements executed
 plpgsql            | 1.0     | pg_catalog | PL/pgSQL procedural language
(2 rows)

pega=> SELECT * FROM pg_extension;
  oid   |      extname       | extowner | extnamespace | extrelocatable | extversion | extconfig | extcondition
--------+--------------------+----------+--------------+----------------+------------+-----------+--------------
  14359 | plpgsql            |       10 |           11 | f              | 1.0        |           |
 886355 | pg_stat_statements |       10 |         2200 | t              | 1.7        |           |
(2 rows)


