How to Check Postgres Bloat Issue
created by Jie Long on Nov 23, 2016 1:44 PM, last modified by Jie Long on Nov 12, 2019 6:20 PMVersion 10
Postgres autovacuum/vacuum reclaims storage occupied by dead tuples and mark it available for reuse. However, extra space is not returned to the operating system (in most cases); it's just kept available for re-use within the same table. On hot updated tables, Postgres presents a bloating issue. This causes table fragmentation and storage issue. For table which encounter large batch insert/delete/update, the customer encounter postgres data file size grow out of control quickly. The current official option is scheduling 'vacuum full analyze' periodically. But this requires downtime and large space planning.  'vacuum full' accordingly takes much longer and requires exclusively locks on the tables. It also requires extra disk space, since it writes a new copy of the table and doesn't release the old copy until the operation is complete.

 

Queries to check bloating issue. These queries are compiled from Postgres community: Show database bloat - PostgreSQL wiki and  https://bucardo.org/wiki/Check_postgres

 

Note: need to cross check the table/blob size using pg_total_relation_size, pg_table_size, pg_relation_size. As the following views count on stats updated after autovacuum. When the stats are missing or behind, the views may gave incorrect info. The alternative is to use pgstattuple, which is available on AWS.  pgstattuple does a full table scan, so it may be more expensive.

 

Query to check  table/index bloat not including pg_toast tables
 

CREATE OR REPLACE VIEW bloat AS

      SELECT

        schemaname, tablename, reltuples::bigint, relpages::bigint, otta,

        ROUND(CASE WHEN otta=0 THEN 0.0 ELSE sml.relpages/otta::numeric END,1) AS tbloat,

        relpages::bigint - otta AS wastedpages,

        bs*(sml.relpages-otta)::bigint AS wastedbytes,

        pg_size_pretty((bs*(relpages-otta))::bigint) AS wastedsize,

        iname, ituples::bigint, ipages::bigint, iotta,

        ROUND(CASE WHEN iotta=0 OR ipages=0 THEN 0.0 ELSE ipages/iotta::numeric END,1) AS ibloat,

        CASE WHEN ipages < iotta THEN 0 ELSE ipages::bigint - iotta END AS wastedipages,

        CASE WHEN ipages < iotta THEN 0 ELSE bs*(ipages-iotta) END AS wastedibytes,

        CASE WHEN ipages < iotta THEN pg_size_pretty(0::bigint) ELSE pg_size_pretty((bs*(ipages-iotta))::bigint) END AS wastedisize

      FROM (

        SELECT

          schemaname, tablename, cc.reltuples, cc.relpages, bs,

          CEIL((cc.reltuples*((datahdr+ma-

            (CASE WHEN datahdr%ma=0 THEN ma ELSE datahdr%ma END))+nullhdr2+4))/(bs-20::float)) AS otta,

          COALESCE(c2.relname,'?') AS iname, COALESCE(c2.reltuples,0) AS ituples, COALESCE(c2.relpages,0) AS ipages,

          COALESCE(CEIL((c2.reltuples*(datahdr-12))/(bs-20::float)),0) AS iotta -- very rough approximation, assumes all cols

        FROM (

          SELECT

            ma,bs,schemaname,tablename,

            (datawidth+(hdr+ma-(case when hdr%ma=0 THEN ma ELSE hdr%ma END)))::numeric AS datahdr,

            (maxfracsum*(nullhdr+ma-(case when nullhdr%ma=0 THEN ma ELSE nullhdr%ma END))) AS nullhdr2

          FROM (

            SELECT

              schemaname, tablename, hdr, ma, bs,

              SUM((1-null_frac)*avg_width) AS datawidth,

              MAX(null_frac) AS maxfracsum,

              hdr+(

                SELECT 1+count(*)/8

                FROM pg_stats s2

                WHERE null_frac<>0 AND s2.schemaname = s.schemaname AND s2.tablename = s.tablename

              ) AS nullhdr

            FROM pg_stats s, (

              SELECT

                (SELECT current_setting('block_size')::numeric) AS bs,

                CASE WHEN substring(v,12,3) IN ('8.0','8.1','8.2') THEN 27 ELSE 23 END AS hdr,

                CASE WHEN v ~ 'mingw32' THEN 8 ELSE 4 END AS ma

              FROM (SELECT version() AS v) AS foo

            ) AS constants

            GROUP BY 1,2,3,4,5

          ) AS foo

        ) AS rs

        JOIN pg_class cc ON cc.relname = rs.tablename

        JOIN pg_namespace nn ON cc.relnamespace = nn.oid AND nn.nspname = rs.schemaname

        LEFT JOIN pg_index i ON indrelid = cc.oid

        LEFT JOIN pg_class c2 ON c2.oid = i.indexrelid

      ) AS sml

      WHERE sml.relpages - otta > 0 OR ipages - iotta > 10

      ORDER BY wastedbytes DESC, wastedibytes DESC;

 

select * from bloat;

 

 

Query to check  table bloat including pg_toast tables without index:
CREATE OR REPLACE VIEW table_bloat AS

 

SELECT current_database(), schemaname, tblname, bs*tblpages AS real_size,
  (tblpages-est_tblpages)*bs AS extra_size,
  CASE WHEN tblpages - est_tblpages > 0
    THEN 100 * (tblpages - est_tblpages)/tblpages::float
    ELSE 0
  END AS extra_ratio, fillfactor, (tblpages-est_tblpages_ff)*bs AS bloat_size,
  CASE WHEN tblpages - est_tblpages_ff > 0
    THEN 100 * (tblpages - est_tblpages_ff)/tblpages::float
    ELSE 0
  END AS bloat_ratio, is_na
  -- , (pst).free_percent + (pst).dead_tuple_percent AS real_frag
FROM (
  SELECT ceil( reltuples / ( (bs-page_hdr)/tpl_size ) ) + ceil( toasttuples / 4 ) AS est_tblpages,
    ceil( reltuples / ( (bs-page_hdr)*fillfactor/(tpl_size*100) ) ) + ceil( toasttuples / 4 ) AS est_tblpages_ff,
    tblpages, fillfactor, bs, tblid, schemaname, tblname, heappages, toastpages, is_na
    -- , stattuple.pgstattuple(tblid) AS pst
  FROM (
    SELECT
      ( 4 + tpl_hdr_size + tpl_data_size + (2*ma)
        - CASE WHEN tpl_hdr_size%ma = 0 THEN ma ELSE tpl_hdr_size%ma END
        - CASE WHEN ceil(tpl_data_size)::int%ma = 0 THEN ma ELSE ceil(tpl_data_size)::int%ma END
      ) AS tpl_size, bs - page_hdr AS size_per_block, (heappages + toastpages) AS tblpages, heappages,
      toastpages, reltuples, toasttuples, bs, page_hdr, tblid, schemaname, tblname, fillfactor, is_na
    FROM (
      SELECT
        tbl.oid AS tblid, ns.nspname AS schemaname, tbl.relname AS tblname, tbl.reltuples,
        tbl.relpages AS heappages, coalesce(toast.relpages, 0) AS toastpages,
        coalesce(toast.reltuples, 0) AS toasttuples,
        coalesce(substring(
          array_to_string(tbl.reloptions, ' ')
          FROM '%fillfactor=#"__#"%' FOR '#')::smallint, 100) AS fillfactor,
        current_setting('block_size')::numeric AS bs,
        CASE WHEN version()~'mingw32' OR version()~'64-bit|x86_64|ppc64|ia64|amd64' THEN 8 ELSE 4 END AS ma,
        24 AS page_hdr,
        23 + CASE WHEN MAX(coalesce(null_frac,0)) > 0 THEN ( 7 + count(*) ) / 8 ELSE 0::int END
          + CASE WHEN tbl.relhasoids THEN 4 ELSE 0 END AS tpl_hdr_size,
        sum( (1-coalesce(s.null_frac, 0)) * coalesce(s.avg_width, 1024) ) AS tpl_data_size,
        bool_or(att.atttypid = 'pg_catalog.name'::regtype) AS is_na
      FROM pg_attribute AS att
        JOIN pg_class AS tbl ON att.attrelid = tbl.oid
        JOIN pg_namespace AS ns ON ns.oid = tbl.relnamespace
        JOIN pg_stats AS s ON s.schemaname=ns.nspname
          AND s.tablename = tbl.relname AND s.inherited=false AND s.attname=att.attname
        LEFT JOIN pg_class AS toast ON tbl.reltoastrelid = toast.oid
      WHERE att.attnum > 0 AND NOT att.attisdropped
        AND tbl.relkind = 'r'
      GROUP BY 1,2,3,4,5,6,7,8,9,10, tbl.relhasoids
      ORDER BY 2,3
    ) AS s
  ) AS s2
) AS s3
order by bloat_ratio desc, bloat_ratio desc;

 

select * from table_bloat;

 

Query to check  index bloat only
create or replace view index_bloat as

SELECT current_database(), nspname AS schemaname, tblname, idxname, bs*(relpages)::bigint AS real_size,

  bs*(relpages-est_pages)::bigint AS extra_size,

  100 * (relpages-est_pages)::float / relpages AS extra_ratio,

  fillfactor, bs*(relpages-est_pages_ff) AS bloat_size,

  100 * (relpages-est_pages_ff)::float / relpages AS bloat_ratio,

  is_na

  -- , 100-(sub.pst).avg_leaf_density, est_pages, index_tuple_hdr_bm, maxalign, pagehdr, nulldatawidth, nulldatahdrwidth, sub.reltuples, sub.relpages -- (DEBUG INFO)

FROM (

  SELECT coalesce(1 +

       ceil(reltuples/floor((bs-pageopqdata-pagehdr)/(4+nulldatahdrwidth)::float)), 0 -- ItemIdData size + computed avg size of a tuple (nulldatahdrwidth)

    ) AS est_pages,

    coalesce(1 +

       ceil(reltuples/floor((bs-pageopqdata-pagehdr)*fillfactor/(100*(4+nulldatahdrwidth)::float))), 0

    ) AS est_pages_ff,

    bs, nspname, table_oid, tblname, idxname, relpages, fillfactor, is_na

    -- , stattuple.pgstatindex(quote_ident(nspname)||'.'||quote_ident(idxname)) AS pst, index_tuple_hdr_bm, maxalign, pagehdr, nulldatawidth, nulldatahdrwidth, reltuples -- (DEBUG INFO)

  FROM (

    SELECT maxalign, bs, nspname, tblname, idxname, reltuples, relpages, relam, table_oid, fillfactor,

      ( index_tuple_hdr_bm +

          maxalign - CASE -- Add padding to the index tuple header to align on MAXALIGN

            WHEN index_tuple_hdr_bm%maxalign = 0 THEN maxalign

            ELSE index_tuple_hdr_bm%maxalign

          END

        + nulldatawidth + maxalign - CASE -- Add padding to the data to align on MAXALIGN

            WHEN nulldatawidth = 0 THEN 0

            WHEN nulldatawidth::integer%maxalign = 0 THEN maxalign

            ELSE nulldatawidth::integer%maxalign

          END

      )::numeric AS nulldatahdrwidth, pagehdr, pageopqdata, is_na

      -- , index_tuple_hdr_bm, nulldatawidth -- (DEBUG INFO)

    FROM (

      SELECT

        i.nspname, i.tblname, i.idxname, i.reltuples, i.relpages, i.relam, a.attrelid AS table_oid,

        current_setting('block_size')::numeric AS bs, fillfactor,

        CASE -- MAXALIGN: 4 on 32bits, 8 on 64bits (and mingw32 ?)

          WHEN version() ~ 'mingw32' OR version() ~ '64-bit|x86_64|ppc64|ia64|amd64' THEN 8

          ELSE 4

        END AS maxalign,

        /* per page header, fixed size: 20 for 7.X, 24 for others */

        24 AS pagehdr,

        /* per page btree opaque data */

        16 AS pageopqdata,

        /* per tuple header: add IndexAttributeBitMapData if some cols are null-able */

        CASE WHEN max(coalesce(s.null_frac,0)) = 0

          THEN 2 -- IndexTupleData size

          ELSE 2 + (( 32 + 8 - 1 ) / 8) -- IndexTupleData size + IndexAttributeBitMapData size ( max num filed per index + 8 - 1 /8)

        END AS index_tuple_hdr_bm,

        /* data len: we remove null values save space using it fractionnal part from stats */

        sum( (1-coalesce(s.null_frac, 0)) * coalesce(s.avg_width, 1024)) AS nulldatawidth,

        max( CASE WHEN a.atttypid = 'pg_catalog.name'::regtype THEN 1 ELSE 0 END ) > 0 AS is_na

      FROM pg_attribute AS a

        JOIN (

          SELECT nspname, tbl.relname AS tblname, idx.relname AS idxname, idx.reltuples, idx.relpages, idx.relam,

            indrelid, indexrelid, indkey::smallint[] AS attnum,

            coalesce(substring(

              array_to_string(idx.reloptions, ' ')

               from 'fillfactor=([0-9]+)')::smallint, 90) AS fillfactor

          FROM pg_index

            JOIN pg_class idx ON idx.oid=pg_index.indexrelid

            JOIN pg_class tbl ON tbl.oid=pg_index.indrelid

            JOIN pg_namespace ON pg_namespace.oid = idx.relnamespace

          WHERE pg_index.indisvalid AND tbl.relkind = 'r' AND idx.relpages > 0

        ) AS i ON a.attrelid = i.indexrelid

        JOIN pg_stats AS s ON s.schemaname = i.nspname

          AND ((s.tablename = i.tblname AND s.attname = pg_catalog.pg_get_indexdef(a.attrelid, a.attnum, TRUE)) -- stats from tbl

          OR   (s.tablename = i.idxname AND s.attname = a.attname))-- stats from functionnal cols

        JOIN pg_type AS t ON a.atttypid = t.oid

      WHERE a.attnum > 0

      GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9

    ) AS s1

  ) AS s2

    JOIN pg_am am ON s2.relam = am.oid WHERE am.amname = 'btree'

) AS sub

ORDER BY bloat_size desc, bloat_ratio desc; --2,3,4;

 

 

 

Find tables (including relative toast tables) bloating info along with vacuum status.

 

select tblname, real_size  , extra_size , extra_ratio  , fillfactor, bloat_size , bloat_ratio, n_live_tup, n_dead_tup,last_vacuum, last_autovacuum,last_analyze, last_autoanalyze from table_bloat bloat, pg_stat_all_tables stat where bloat.tblname=stat.relname and bloat_ratio>40 and n_live_tup!=0 order by bloat.bloat_ratio desc;



copy results to a csv file example:

\copy (select tblname, real_size  , extra_size , extra_ratio  , fillfactor, bloat_size , bloat_ratio, n_live_tup, n_dead_tup,last_vacuum, last_autovacuum,last_analyze, last_autoanalyze from table_bloat bloat, pg_stat_all_tables stat where bloat.tblname=stat.relname and bloat_ratio>40 and n_live_tup!=0 order by bloat.bloat_ratio desc) to '/local/pega-work/sync-data/Tables_with_40_and_more_bloat.csv' with csv header;



-------------------------------------------- Index bloat(not tested).
Query-1 : Table/index with out toast.
Query-2 : table + toast without indexes.
query-3 : Only indexes.
-------------------------------------------- Index bloat(not tested).
WITH btree_index_atts AS ( SELECT nspname,  indexclass.relname as index_name, indexclass.reltuples, indexclass.relpages, indrelid, indexrelid, indexclass.relam, tableclass.relname as tablename, regexp_split_to_table(indkey::text, ' ')::smallint AS attnum, indexrelid as index_oid FROM pg_index JOIN pg_class AS indexclass ON pg_index.indexrelid = indexclass.oid JOIN pg_class AS tableclass ON pg_index.indrelid = tableclass.oid JOIN pg_namespace ON pg_namespace.oid = indexclass.relnamespace JOIN pg_am ON indexclass.relam = pg_am.oid WHERE pg_am.amname = 'btree' and indexclass.relpages > 0 AND nspname NOT IN ('pg_catalog','information_schema')), index_item_sizes AS ( SELECT ind_atts.nspname, ind_atts.index_name,     ind_atts.reltuples, ind_atts.relpages, ind_atts.relam, indrelid AS table_oid, index_oid, current_setting('block_size')::numeric AS bs, 8 AS maxalign, 24 AS pagehdr, CASE WHEN  max(coalesce(pg_stats.null_frac,0)) = 0 THEN 2 ELSE 6 END AS index_tuple_hdr,  sum( (1-coalesce(pg_stats.null_frac, 0)) * coalesce(pg_stats.avg_width, 1024) ) AS nulldatawidth  FROM pg_attribute JOIN btree_index_atts AS ind_atts ON pg_attribute.attrelid = ind_atts.indexrelid AND pg_attribute.attnum = ind_atts.attnum  JOIN pg_stats ON pg_stats.schemaname = ind_atts.nspname
-- stats for regular index columns
AND ( (pg_stats.tablename = ind_atts.tablename AND pg_stats.attname = pg_catalog.pg_get_indexdef(pg_attribute.attrelid, pg_attribute.attnum, TRUE))
-- stats for functional indexes
OR   (pg_stats.tablename = ind_atts.index_name AND pg_stats.attname = pg_attribute.attname))  WHERE pg_attribute.attnum > 0 GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9), index_aligned_est AS ( SELECT maxalign, bs, nspname, index_name, reltuples, relpages, relam, table_oid, index_oid, coalesce ( ceil ( reltuples * ( 6 + maxalign

CASE
WHEN index_tuple_hdr%maxalign = 0 THEN maxalign ELSE index_tuple_hdr%maxalign END + nulldatawidth + maxalign
CASE /* Add padding to the data to align on MAXALIGN /
WHEN nulldatawidth::integer%maxalign = 0 THEN maxalign ELSE nulldatawidth::integer%maxalign END )::numeric / ( bs - pagehdr::NUMERIC ) +1 ) , 0 ) as expected FROM index_item_sizes ),
raw_bloat AS ( SELECT current_database() as dbname, nspname, pg_class.relname AS table_name, index_name,bs(index_aligned_est.relpages)::bigint AS totalbytes, expected, CASE WHEN index_aligned_est.relpages <= expected THEN 0 ELSE bs*(index_aligned_est.relpages-expected)::bigint END AS wastedbytes, CASE WHEN index_aligned_est.relpages <= expected THEN 0 ELSE bs*(index_aligned_est.relpages-expected)::bigint * 100 / (bs*(index_aligned_est.relpages)::bigint) END AS realbloat, pg_relation_size(index_aligned_est.table_oid) as table_bytes, stat.idx_scan as index_scans FROM index_aligned_est JOIN pg_class ON pg_class.oid=index_aligned_est.table_oid JOIN pg_stat_user_indexes AS stat ON index_aligned_est.index_oid = stat.indexrelid ), format_bloat AS ( SELECT dbname as database_name, nspname as schema_name, table_name, index_name, round(realbloat) as bloat_pct, round(wastedbytes/(1024^2)::NUMERIC) as bloat_mb, round(totalbytes/(1024^2)::NUMERIC,3) as index_mb, round(table_bytes/(1024^2)::NUMERIC,3) as table_mb, index_scans FROM raw_bloat ) SELECT * FROM format_bloat WHERE ( bloat_pct > 25 and bloat_mb > 500 ) ORDER BY bloat_mb DESC;

