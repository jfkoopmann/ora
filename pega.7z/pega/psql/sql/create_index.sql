pega=> show maintenance_work_mem;
 maintenance_work_mem
----------------------
 239457kB
(1 row)

pega=> set maintenance_work_mem to '2GB';
SET
pega=> show maintenance_work_mem;
 maintenance_work_mem
----------------------
 2GB
(1 row)

88GB table
11:32am MST

pega=> CREATE INDEX pxobjkeyattachkey ON pegadata.pc_data_workattach USING btree (pxrefobjectkey, pxattachkey);
CREATE INDEX

11:37am MST

pega=> \q

[root@ip-161-32-38-92 ~]# pega-psql
\psql (12.5, server 11.5)
SSL connection (protocol: TLSv1.2, cipher: ECDHE-RSA-AES256-GCM-SHA384, bits: 256, compression: off)
Type "help" for help.

pega=> show maintenance_work_mem;
 maintenance_work_mem
----------------------
 239457kB
(1 row)

pega=>
