#-- import .csv into table

#-- check current row count
pega=> select count(*) from customerdata.OFFER_CONTEXT;
 count
-------
     0
(1 row)


#-- bring over .csv file
[root@ip-161-32-34-59 ~]# cat i.csv
id,parentdealid,gdpr_temp_override,care_flag,call_reason_mode,cost_to_customer_one_off,contract_end_date_old,contract_length_old,deal_type,early_upg_discount,handset_old,handset_new,mod_rec_flag,rec_count_items,mrc_new,mrc_old,brand_name_old,rv_percentage,store_code,rct_manager_id,rct_reason,src_investment_value,subscriptionid,brand_name_new,tariff_old,tariff_new,start_tier,tier_type,disc_amount_old,disc_amount_new,resign_period,pre_deal_6mth_avg_data,pre_deal_6mth_avg_sms,pre_deal_6mth_avg_voice,pre_deal_ic_cost,pre_deal_ic_revenue,segment,rec_name,rec_type,rec_flag,converged_customer_key,acxiom_key,converged_hbb_brand,converged_hbb_product,converged_hbb_end_date,create_date,sub_deal_id,ocf_flag,tile,price_rise,oob_pr_cancellation,orig_tariff_family,cost_disc_monthly,cost_oneoff_exc_disc,postcode_used,manual_reason,data_boost,data_boost_summary,home_pin_text_1,home_pin_text_2,subscription_reference,negative_deal_info_1,negative_deal_info_2,pl_allowed_flag,existing_loan_plan_flag,total_loan_amount,trade_in_amount,trade_in_excess,income_pass_flag,affordability_pass_flag,direct_match_price,org_handset_price,end_budget,fnl_handset_price,start_budget,src_total,total_no_of_ctns_in_basket,total_no_of_elig_ctns,no_of_prop_deals,propagate_from_id,service_num
16203,,1,0,Inbound,400,20210318T000000.000 GMT,24,UP,0,APPLE IPHONE 6S,APPLE IPHONE 12 MINI 5G 128GB Black,0,0,51,47.57,EE,1.15,,,,704.4,1123356617,EE,X17F24M19,X20P24U01,1,1,11.12,-10.2,24,0,0,0,0,0,PAYM,,,0,162285512,,EE,[HIDE],19700101T000000.000 GMT,20210621T081105.890 GMT,1,1,,0,19700101T050000.000 GMT,,0,0,,,,,,,,,,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,,7497083157
4906,,2,1,Inbound,236.65,20220606T000000.000 GMT,24,UP,0,SAMSUNG GALAXY S9 G960F LTE,Non handset deal,0,2,20,37.2,EE,1.15,,,,0,100122487,EE,X20AH0166,XSAWEAR05,1,1,0,0,24,23081,23,4,1.51,0.46,PAYM,SAM21P128|X21PEL119,A,1,100122487,,EE,[HIDE],19700101T000000.000 GMT,20210924T090340.701 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,7539759711
69060,,2,0,Inbound,0,20200821T000000.000 GMT,24,UP,0,N/A,APPLE IPHONE SE 2020 128GB Red,0,0,51,49.99,EE,1.15,,,,422.4,141617683,EE,X19A24H05,X21ISF001,1,1,17.4,-15.3,24,9999,0,9,4.32,0.39,PAYM,,,0,141617683,,EE,[HIDE],19700101T000000.000 GMT,20210906T184534.489 GMT,1,1,,0,19691231T230000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,7581442126
4891,,2,1,Inbound,0,20220606T000000.000 GMT,24,ADD,0,SAMSUNG GALAXY S9 G960F LTE,APPLE WATCH SE 44MM GREY CASE + CHARCOAL LOOP Grey,0,2,24,37.2,EE,1.15,,,,315.6,1148019265,EE,X20AH0166,XSAWEAR11,1,1,0,0,24,23081,23,4,1.51,0.46,PAYM,AWSEGRCCL44|XSAWEAR11,A,1,102196832,,EE,[HIDE],19700101T000000.000 GMT,20210920T095322.332 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,102196832-1
4900,,2,1,Inbound,0,20201222T000000.000 GMT,0,ADD,0,SAMSUNG GALAXY WATCH 46MM,APPLE WATCH S3 38MM 2018 SILVER WHITE BAND Silver,0,2,20,0,EE,1.15,,,,271.2,1143954980,EE,,X19WEAR03,1,1,0,0,24,0,0,0,0,0,PAYM,IP12M64|X21ISL052,A,1,128547158,62128025,EE,[HIDE],19700101T000000.000 GMT,20210920T115842.631 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,128547158-1
4905,,2,1,Inbound,0,20200725T000000.000 GMT,0,ADD,0,SAMSUNG T719,APPLE WATCH S3 38MM 2018 SILVER WHITE BAND Silver,0,0,20,0,EE,1.15,,,,271.2,1128626064,EE,,X19WEAR03,1,1,0,0,24,1349,0,0,0,0,PAYM,,,0,104766440,,EE,[HIDE],19700101T000000.000 GMT,20210920T134308.521 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,104766440-1
4867,,2,1,Inbound,0,20221109T000000.000 GMT,24,UP,0,APPLE IPHONE 7,Non handset deal,0,0,44,36,EE,1.15,,,,0,9.00133E+11,EE,X21ISL048,X21ISL087,1,1,11.47,0,13,26274,98,1,0.5,0.14,PAYM,,,0,141617683,,EE,[HIDE],19700101T000000.000 GMT,20210910T132825.478 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,7581442126
4667,,2,1,Inbound,14.99,20210429T000000.000 GMT,24,UP,0,APPLE IPHONE 7,Non handset deal,0,0,18,10,EE,1.15,,,,0,1093317142,EE,X20C18S01,X20E24S05,1,1,5.4,0,24,594,13,1,0.05,0.01,PAYM,,,0,143439236,,EE,[HIDE],19700101T000000.000 GMT,20210923T103116.149 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,,7996241507
4910,,2,1,Inbound,0,20201222T000000.000 GMT,0,UP,0,N/A,Non handset deal,0,0,5,0,EE,1.15,,,,0,100202158,EE,,X20WEAR01,1,1,0,-2,12,0,0,0,0,0,PAYM,Promo_EE_Watch_DR4145_2,Promo,1,100202158,,EE,[HIDE],19700101T000000.000 GMT,20210924T094009.516 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,7837987934
68960,,2,0,Inbound,0,20200821T000000.000 GMT,24,UP,0,N/A,APPLE IPHONE SE 2020 128GB Black,0,0,51,49.99,EE,1.15,,,,422.4,1085974667,EE,X19A24H05,X21ISF001,1,1,17.4,0,24,9999,0,9,0,0,PAYM,,,0,118070968,,EE,[HIDE],19700101T000000.000 GMT,20210927T110603.997 GMT,1,1,,,,,,,,,,,,,,,,1,0,,,,1,0,,,0,,,,,,,,7508420311
69061,,2,0,Inbound,0,20200821T000000.000 GMT,24,UP,0,N/A,APPLE IPHONE SE 2020 128GB Red,0,0,51,49.99,EE,1.15,,,,422.4,1328867050::165410625,EE,X19A24H05,X21ISF001,1,1,17.4,-15.3,24,9999,0,9,4.32,0.39,PAYM,,,0,1328867050::165410625,,EE,[HIDE],19700101T000000.000 GMT,20210927T110604.410 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,1642551500
68965,,2,1,Inbound,0,20200821T000000.000 GMT,24,UP,0,N/A,SAMSUNG A02S Black,0,0,26,49.99,EE,1.15,,,,121.2,VOLEE-222222222,EE,X19A24H05,X21ASL001,1,1,17.4,0,24,9999,0,9,0,0,PAYM,,,0,1326558390,,EE,[HIDE],19700101T000000.000 GMT,20210927T140754.606 GMT,1,1,,0,19700101T000000.000 GMT,,0,0,,,,,,,,,,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,,7384595069

#-- create COPY statement
[root@ip-161-32-34-59 ~]# cat h.sql
\COPY customerdata.OFFER_CONTEXT(id,parentdealid,gdpr_temp_override,care_flag,call_reason_mode,cost_to_customer_one_off,contract_end_date_old,contract_length_old,deal_type,early_upg_discount,handset_old,han
dset_new,mod_rec_flag,rec_count_items,mrc_new,mrc_old,brand_name_old,rv_percentage,store_code,rct_manager_id,rct_reason,src_investment_value,subscriptionid,brand_name_new,tariff_old,tariff_new,start_tier,ti
er_type,disc_amount_old,disc_amount_new,resign_period,pre_deal_6mth_avg_data,pre_deal_6mth_avg_sms,pre_deal_6mth_avg_voice,pre_deal_ic_cost,pre_deal_ic_revenue,segment,rec_name,rec_type,rec_flag,converged_c
ustomer_key,acxiom_key,converged_hbb_brand,converged_hbb_product,converged_hbb_end_date,create_date,sub_deal_id,ocf_flag,tile,price_rise,oob_pr_cancellation,orig_tariff_family,cost_disc_monthly,cost_oneoff_
exc_disc,postcode_used,manual_reason,data_boost,data_boost_summary,home_pin_text_1,home_pin_text_2,subscription_reference,negative_deal_info_1,negative_deal_info_2,pl_allowed_flag,existing_loan_plan_flag,to
tal_loan_amount,trade_in_amount,trade_in_excess,income_pass_flag,affordability_pass_flag,direct_match_price,org_handset_price,end_budget,fnl_handset_price,start_budget,src_total,total_no_of_ctns_in_basket,t
otal_no_of_elig_ctns,no_of_prop_deals,propagate_from_id,service_num) FROM 'i.csv' DELIMITER ',' CSV HEADER;

#-- execute COPY command
[root@ip-161-32-34-59 ~]# pega-psql
psql (12.5, server 11.5)
SSL connection (protocol: TLSv1.2, cipher: ECDHE-RSA-AES256-GCM-SHA384, bits: 256, compression: off)
Type "help" for help.

pega=> \i h.sql
COPY 12

#-- validate new row count
pega=> select count(*) from customerdata.OFFER_CONTEXT;
 count
-------
    12
(1 row)
