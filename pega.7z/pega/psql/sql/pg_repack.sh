====================================================================================================================== PG_REPACK
step0) copy from s3 if needed
aws s3 cp s3://cuttyhunk-prod/pe-prod/services/ec2-tools/pg_repack_1.4.4 pg_repack
aws s3 cp s3://cuttyhunk-prod/pe-prod/services/ec2-tools/pg_repack* .

-------------- From Hiu:

setp0.1) check size
--all tables
SELECT * FROM( SELECT schemaname, tblname, bs*tblpages AS real_size,pg_size_pretty(pg_total_relation_size(schemaname||'.'||tblname)) As total_table_size, (tblpages-est_tblpages)*bs AS extra_size, fillfactor, (tblpages-est_tblpages_ff)*bs AS bloat_size, CASE WHEN tblpages - est_tblpages_ff > 0 THEN 100 * (tblpages - est_tblpages_ff)/tblpages::float ELSE 0 END AS bloat_ratio FROM (SELECT ceil( reltuples / ( (bs-page_hdr)/tpl_size ) ) + ceil( toasttuples / 4 ) AS est_tblpages, ceil( reltuples / ( (bs-page_hdr)*fillfactor/(tpl_size*100) ) ) + ceil( toasttuples / 4 ) AS est_tblpages_ff, tblpages, fillfactor, bs, tblid, schemaname, tblname, heappages, toastpages, is_na FROM (SELECT ( 4 + tpl_hdr_size + tpl_data_size + (2*ma) - CASE WHEN tpl_hdr_size%ma = 0 THEN ma ELSE tpl_hdr_size%ma END - CASE WHEN ceil(tpl_data_size)::int%ma = 0 THEN ma ELSE ceil(tpl_data_size)::int%ma END) AS tpl_size, bs - page_hdr AS size_per_block, (heappages + toastpages) AS tblpages, heappages, toastpages, reltuples, toasttuples, bs, page_hdr, tblid, schemaname, tblname, fillfactor, is_na FROM (SELECT tbl.oid AS tblid, ns.nspname AS schemaname, tbl.relname AS tblname, tbl.reltuples, tbl.relpages AS heappages, coalesce(toast.relpages, 0) AS toastpages, coalesce(toast.reltuples, 0) AS toasttuples, coalesce(substring( array_to_string(tbl.reloptions, ' ') FROM '%fillfactor=#"__#"%' FOR '#')::smallint, 100) AS fillfactor, current_setting('block_size')::numeric AS bs, CASE WHEN version()~'mingw32' OR version()~'64-bit|x86_64|ppc64|ia64|amd64' THEN 8 ELSE 4 END AS ma, 24 AS page_hdr, 23 + CASE WHEN MAX(coalesce(null_frac,0)) > 0 THEN ( 7 + count(*) ) / 8 ELSE 0::int END + CASE WHEN tbl.relhasoids THEN 4 ELSE 0 END AS tpl_hdr_size, sum( (1-coalesce(s.null_frac, 0)) * coalesce(s.avg_width, 1024) ) AS tpl_data_size, bool_or(att.atttypid = 'pg_catalog.name'::regtype) AS is_na FROM pg_attribute AS att JOIN pg_class AS tbl ON att.attrelid = tbl.oid JOIN pg_namespace AS ns ON ns.oid = tbl.relnamespace JOIN pg_stats AS s ON s.schemaname=ns.nspname AND s.tablename = tbl.relname AND s.inherited=false AND s.attname=att.attname LEFT JOIN pg_class AS toast ON tbl.reltoastrelid = toast.oid WHERE att.attnum > 0 AND NOT att.attisdropped AND tbl.relkind = 'r' GROUP BY 1,2,3,4,5,6,7,8,9,10, tbl.relhasoids ORDER BY 2,3 ) AS s ) AS s2 ) AS s3 ) AS s4 where bloat_size > 524288000;

--pegadata/customerdata tables
SELECT * FROM( SELECT schemaname, tblname, bs*tblpages AS real_size,pg_size_pretty(pg_total_relation_size(schemaname||'.'||tblname)) As total_table_size, (tblpages-est_tblpages)*bs AS extra_size, fillfactor, (tblpages-est_tblpages_ff)*bs AS bloat_size, CASE WHEN tblpages - est_tblpages_ff > 0 THEN 100 * (tblpages - est_tblpages_ff)/tblpages::float ELSE 0 END AS bloat_ratio FROM (SELECT ceil( reltuples / ( (bs-page_hdr)/tpl_size ) ) + ceil( toasttuples / 4 ) AS est_tblpages, ceil( reltuples / ( (bs-page_hdr)*fillfactor/(tpl_size*100) ) ) + ceil( toasttuples / 4 ) AS est_tblpages_ff, tblpages, fillfactor, bs, tblid, schemaname, tblname, heappages, toastpages, is_na FROM (SELECT ( 4 + tpl_hdr_size + tpl_data_size + (2*ma) - CASE WHEN tpl_hdr_size%ma = 0 THEN ma ELSE tpl_hdr_size%ma END - CASE WHEN ceil(tpl_data_size)::int%ma = 0 THEN ma ELSE ceil(tpl_data_size)::int%ma END) AS tpl_size, bs - page_hdr AS size_per_block, (heappages + toastpages) AS tblpages, heappages, toastpages, reltuples, toasttuples, bs, page_hdr, tblid, schemaname, tblname, fillfactor, is_na FROM (SELECT tbl.oid AS tblid, ns.nspname AS schemaname, tbl.relname AS tblname, tbl.reltuples, tbl.relpages AS heappages, coalesce(toast.relpages, 0) AS toastpages, coalesce(toast.reltuples, 0) AS toasttuples, coalesce(substring( array_to_string(tbl.reloptions, ' ') FROM '%fillfactor=#"__#"%' FOR '#')::smallint, 100) AS fillfactor, current_setting('block_size')::numeric AS bs, CASE WHEN version()~'mingw32' OR version()~'64-bit|x86_64|ppc64|ia64|amd64' THEN 8 ELSE 4 END AS ma, 24 AS page_hdr, 23 + CASE WHEN MAX(coalesce(null_frac,0)) > 0 THEN ( 7 + count(*) ) / 8 ELSE 0::int END + CASE WHEN tbl.relhasoids THEN 4 ELSE 0 END AS tpl_hdr_size, sum( (1-coalesce(s.null_frac, 0)) * coalesce(s.avg_width, 1024) ) AS tpl_data_size, bool_or(att.atttypid = 'pg_catalog.name'::regtype) AS is_na FROM pg_attribute AS att JOIN pg_class AS tbl ON att.attrelid = tbl.oid JOIN pg_namespace AS ns ON ns.oid = tbl.relnamespace JOIN pg_stats AS s ON s.schemaname=ns.nspname AND s.tablename = tbl.relname AND s.inherited=false AND s.attname=att.attname LEFT JOIN pg_class AS toast ON tbl.reltoastrelid = toast.oid WHERE att.attnum > 0 AND NOT att.attisdropped AND tbl.relkind = 'r' GROUP BY 1,2,3,4,5,6,7,8,9,10, tbl.relhasoids ORDER BY 2,3 ) AS s ) AS s2 ) AS s3 ) AS s4 where schemaname in ('pegadata','customerdata');
create table bfrepack as ( SELECT * FROM( SELECT schemaname, tblname, bs*tblpages AS real_size,pg_size_pretty(pg_total_relation_size(schemaname||'.'||tblname)) As total_table_size, (tblpages-est_tblpages)*bs AS extra_size, fillfactor, (tblpages-est_tblpages_ff)*bs AS bloat_size, CASE WHEN tblpages - est_tblpages_ff > 0 THEN 100 * (tblpages - est_tblpages_ff)/tblpages::float ELSE 0 END AS bloat_ratio FROM (SELECT ceil( reltuples / ( (bs-page_hdr)/tpl_size ) ) + ceil( toasttuples / 4 ) AS est_tblpages, ceil( reltuples / ( (bs-page_hdr)*fillfactor/(tpl_size*100) ) ) + ceil( toasttuples / 4 ) AS est_tblpages_ff, tblpages, fillfactor, bs, tblid, schemaname, tblname, heappages, toastpages, is_na FROM (SELECT ( 4 + tpl_hdr_size + tpl_data_size + (2*ma) - CASE WHEN tpl_hdr_size%ma = 0 THEN ma ELSE tpl_hdr_size%ma END - CASE WHEN ceil(tpl_data_size)::int%ma = 0 THEN ma ELSE ceil(tpl_data_size)::int%ma END) AS tpl_size, bs - page_hdr AS size_per_block, (heappages + toastpages) AS tblpages, heappages, toastpages, reltuples, toasttuples, bs, page_hdr, tblid, schemaname, tblname, fillfactor, is_na FROM (SELECT tbl.oid AS tblid, ns.nspname AS schemaname, tbl.relname AS tblname, tbl.reltuples, tbl.relpages AS heappages, coalesce(toast.relpages, 0) AS toastpages, coalesce(toast.reltuples, 0) AS toasttuples, coalesce(substring( array_to_string(tbl.reloptions, ' ') FROM '%fillfactor=#"__#"%' FOR '#')::smallint, 100) AS fillfactor, current_setting('block_size')::numeric AS bs, CASE WHEN version()~'mingw32' OR version()~'64-bit|x86_64|ppc64|ia64|amd64' THEN 8 ELSE 4 END AS ma, 24 AS page_hdr, 23 + CASE WHEN MAX(coalesce(null_frac,0)) > 0 THEN ( 7 + count(*) ) / 8 ELSE 0::int END + CASE WHEN tbl.relhasoids THEN 4 ELSE 0 END AS tpl_hdr_size, sum( (1-coalesce(s.null_frac, 0)) * coalesce(s.avg_width, 1024) ) AS tpl_data_size, bool_or(att.atttypid = 'pg_catalog.name'::regtype) AS is_na FROM pg_attribute AS att JOIN pg_class AS tbl ON att.attrelid = tbl.oid JOIN pg_namespace AS ns ON ns.oid = tbl.relnamespace JOIN pg_stats AS s ON s.schemaname=ns.nspname AND s.tablename = tbl.relname AND s.inherited=false AND s.attname=att.attname LEFT JOIN pg_class AS toast ON tbl.reltoastrelid = toast.oid WHERE att.attnum > 0 AND NOT att.attisdropped AND tbl.relkind = 'r' GROUP BY 1,2,3,4,5,6,7,8,9,10, tbl.relhasoids ORDER BY 2,3 ) AS s ) AS s2 ) AS s3 ) AS s4 where schemaname in ('pegadata','customerdata'));

--check unlogged
SELECT relname,
   CASE relpersistence
     WHEN 'u' THEN 'unlogged' 
     WHEN 'p' then 'logged' 
     ELSE 'unknown' END AS table_type
   FROM pg_class
   WHERE relname = 'mktsegdd';

--all tables
SELECT schemaname, relname as "Table", pg_size_pretty(pg_total_relation_size(relid)) As "Size" FROM pg_catalog.pg_stat_user_tables where lower(relname) = 'pc_data_workattach';
 schemaname |       Table        | Size
------------+--------------------+-------
 pegadata   | pc_data_workattach | 94 GB

 schemaname |      tblname       |  real_size   | total_table_size | extra_size  | fillfactor | bloat_size  |   bloat_ratio
------------+--------------------+--------------+------------------+-------------+------------+-------------+------------------
 pegadata   | pc_anah_aides_work | 217057181696 | 208 GB           | 73247637504 |        100 | 73247637504 | 33.7457793064812

step1) connect UTIL tier and execute dry run

/ROOT/PEGACLOUD/LFDJ/CR37860/FDJCRM/eu-central-1/PROD1/prod2[PegaUtilTier] >* run 0 os-pg_repack --TABLE=pegadata.pc_data_workattach,--dry-run
/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6[PegaUtilTier] >* run 0 os-pg_repack --TABLE=pegadata.pc_anah_aides_work,--dry-run

if dry run passed then execute next step.

step2)execute repack

/ROOT/PEGACLOUD/LFDJ/CR37860/FDJCRM/eu-central-1/PROD1/prod2[PegaUtilTier] >run 0 os-pg_repack --TABLE=pegadata.pc_data_workattach
/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6[PegaUtilTier] >* run 0 os-pg_repack --TABLE=pegadata.pc_anah_aides_work
/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6 [PegaUtilTier]  >* run 0 os-pg_repack --TABLE=pegadata.pc_anah_aides_work,--dry-run
. . .

/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6[PegaUtilTier] >* run 0 os-pg_repack --TABLE=pegadata.pc_anah_aides_work
/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6 [PegaUtilTier]  >* run 0 os-pg_repack --show-status

========================================================================================================================
Passed: table check pegadata.pc_anah_aides_work
========================================================================================================================

========================================================================================================================
Passed: DB version check - target verion 11.0.0 and DB ver: 11.5
========================================================================================================================

========================================================================================================================
Passed: Disk Space Check - [ RDS Available Space: 370454377267.2 | PG_REPACK Require Space: 223834251264 ]
========================================================================================================================

Installing pg-repack file to local...
chmod +x pg-repack...
========================================================================================================================
Show DB Bloat Info:
 schemaname |      tblname       |  real_size   | total_table_size | extra_size  | fillfactor | bloat_size  |   bloat_ratio
------------+--------------------+--------------+------------------+-------------+------------+-------------+------------------
 pegadata   | pc_anah_aides_work | 217057181696 | 208 GB           | 73247637504 |        100 | 73247637504 | 33.7457793064812
(1 row)

========================================================================================================================

========================================================================================================================
BEFORE: Current active pg_repack status - 0
AFTER: Current active pg_repack status - 0
========================================================================================================================
Log File: /tmp/pg_repack_20220323-1900.txt
Wed Mar 23 19:00:41 UTC 2022
INFO: Dry run enabled, not executing repack
INFO: repacking table "pegadata.pc_anah_aides_work"

real    0m0.036s
user    0m0.005s
sys     0m0.005s

/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6 [PegaUtilTier]  >* run 0 os-pg_repack --TABLE=pegadata.pc_anah_aides_work
. .

========================================================================================================================
Passed: table check pegadata.pc_anah_aides_work
========================================================================================================================

========================================================================================================================
Passed: DB version check - target verion 11.0.0 and DB ver: 11.5
========================================================================================================================

========================================================================================================================
Passed: Disk Space Check - [ RDS Available Space: 370453928345.6 | PG_REPACK Require Space: 223834251264 ]
========================================================================================================================

========================================================================================================================
Show DB Bloat Info:
 schemaname |      tblname       |  real_size   | total_table_size | extra_size  | fillfactor | bloat_size  |   bloat_ratio
------------+--------------------+--------------+------------------+-------------+------------+-------------+------------------
 pegadata   | pc_anah_aides_work | 217057181696 | 208 GB           | 73247637504 |        100 | 73247637504 | 33.7457793064812
(1 row)

========================================================================================================================

========================================================================================================================
BEFORE: Current active pg_repack status - 0
AFTER: Current active pg_repack status - 2
========================================================================================================================
Log File: /tmp/pg_repack_20220323-1901.txt
Wed Mar 23 19:01:54 UTC 2022
INFO: repacking table "pegadata.pc_anah_aides_work"



step3) monitor status:
/ROOT/PEGACLOUD/LFDJ/CR37860/FDJCRM/eu-central-1/PROD1/prod2[PegaUtilTier] >run 0 os-pg_repack --show-status
/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6[PegaUtilTier] >* run 0 os-pg_repack --show-status
/ROOT/PEGACLOUD/ANAH/CR52115/CITE/eu-west-3/PROD1/prod6 [PegaUtilTier]  >* run 0 os-pg_repack --show-status
.

Check pg_repack_activities:  pid  | application_name |  client_addr  |         backend_start         |          xact_start           |          query_start          |         state_change          | wait_ev
ent_type | wait_event |        state        |                                                                                                                                                                 
                                                                                                                                                                                                              
                                                                                                                                                                                                              
                                                                                                                                                                                                              
                                                                                                                                                                                                              
                                     query                                                                                                                                                                    
                                                                                                                                                                                                              
                                                                                                                                                                                                              
                                                                                                                                                                                                              
                                                                                                                                                                                                              
                                  |  backend_type
------+------------------+---------------+-------------------------------+-------------------------------+-------------------------------+-------------------------------+-----------------+------------+-----
----------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------+----------------
 7189 | pg_repack        | 161.32.38.102 | 2022-03-23 19:01:54.121041+00 | 2022-03-23 19:01:54.209796+00 | 2022-03-23 19:01:54.228836+00 | 2022-03-23 19:01:54.228841+00 |                 |            | acti
ve              | INSERT INTO repack.table_387905 SELECT pxapplication,pxapplicationversion,pxcommitdatetime,pxcoveredcount,pxcoveredcountopen,pxcoveredcountunsatisfied,pxcoverinskey,pxcreatedatetime,pxcrea
teoperator,pxcreateopname,pxcreatesystemid,pxcurrentstage,pxcurrentstagelabel,pxexternalsystemupdatecount,pxflowcount,pxinsname,pxobjclass,pxsavedatetime,pxupdatedatetime,pxupdateoperator,pxupdateopname,pxu
pdatesystemid,pxurgencywork,pyacktimestamp,pyagefromdate,pychargeamount,pychargeto,pycontactchannel,pycontacttype,pycuslevel,pycustomer,pycustomerenterprise,pycustomername,pycustomerorg,pycustomersatisfiedt
imestamp,pydescription,pyeffortactual,pyeffortestimate,pyeffortestimatetimestamp,pyelapsedcustomerack,pyelapsedcustomerunsatisfied,pyelapsedpastdeadline,pyelapsedpastgoal,pyelapsedstatusnew,pyelapsedstatuso
pen,pyelapsedstatuspending,pyeventid,pyfoldertype,pyid,pylabel,pyorigdivision,pyorigorg,pyorigorgunit,pyoriguserdivision,pyoriguserid,pyoriguserworkgroup,pyownerdivision,pyownerorg,pyownerorgunit,pyprimaryc
ontact,pyproblemreason,pyproblemsource,pyproblemtype,pyreopencount,pyreopentimestamp,pyresolutioncomplexity,pyresolutioncost,pyresolveddivision,pyresolvedorg,pyresolvedorgunit,pyresolvedtime,pyresolvedtimes
tamp,pyresolveduserid,pyresolveduserworkgroup,pyrootcause,pysladeadline,pyslagoal,pyslaname,pystatuscustomersat,pystatuswork,pyworklistdate1,pyworklistdatetime1,pyworklistdatetime2,pyworklistdecimal1,pywork
listdecimal2,pyworklistinteger1,pyworklisttext1,pyworklisttext2,pyworklisttext3,pzinskey,pzpvstream,numrofiscal,exposedfulladress,email,hometype,paimenttypecase,occupantfullname,dateofcase,nombrepaiementspa
yesetoppos_1,totalpaiementspayesetopposes_1,puamountworkproject,datedepotdossier,statutetat,statefolder,decisiontake,statutfolderatraiter,ordonnateurencharge,dateoctroi,mpramountworkprojectsolde,iban_paymen
t,decisionordonnateur,typecompterib,typelogement,projectsworkarea,montantvolumedossier,aveccontrole,responsablevisa,controlearealiser,dateoctroiofcase,opposition,totaloppositions,visavalidated,datemiseenpai
ement | client backend
 7190 | pg_repack        | 161.32.38.102 | 2022-03-23 19:01:54.129104+00 | 2022-03-23 19:01:54.206109+00 | 2022-03-23 19:01:54.206488+00 | 2022-03-23 19:01:54.209685+00 | Client          | ClientRead | idle
 in transaction | LOCK TABLE pegadata.pc_anah_aides_work IN ACCESS SHARE MODE                                                                                                                                 
      | client backend
(2 rows)
--------------------------------------------------------------------------------
Wed Mar 23 19:01:54 UTC 2022
INFO: repacking table "pegadata.pc_anah_aides_work"


Try execute couple of times and see the status: if we are getting results then activity is in progress. if not activity completed.

step4) once activity completed. then connect DB and check the table size and update internal note about table size before and after.
there is a limitation with this. you can run only one job at a time


################### Option 2 (I forwarded an email on Oct25 -- Sub :  PG_REPACK 1.4.4)

Download the file to the server
aws s3 cp s3://cuttyhunk-prod/pe-prod/services/ec2-tools/pg_repack_1.4.4 pg_repack

•    Ensure the database version is 11.1 or 11.4
•    Create extension pg_repack (Ignore if already exist).
•    Connect to AppTier/UtilTier and copy the attached pg_repack file.
•    Change the permissions to 755 for “pg_repack” file.

./pg_repack -h pd19z0kdjpcdf3w.cwu3l3mfl0vh.us-east-1.rds.amazonaws.com -U pega -k pega -c pegadata --dry-run
./pg_repack -h pd19z0kdjpcdf3w.cwu3l3mfl0vh.us-east-1.rds.amazonaws.com -U pega -k pega -t pegadata.pc_abbv_us_idp_work_party 

./pg_repack -h pd1qxvqi4g6ru4z-pg-repack-test-ravi.c50b9al4voj7.us-east-2.rds.amazonaws.com -U pega -k pega -t pegadata.sfai_cno_fw_oscrfw_work_contac

./pg_repack -h pd1mbczvgjabnzd.cpr7jifkq2vy.us-east-1.rds.amazonaws.com -U pega -k pega -i pegadata.history_nsa_stat_work_grp1_pk    -- Index

./pg_repack --elevel=debug -h pd1qxvqi4g6ru4z-pg-repack-test-ravi.c50b9al4voj7.us-east-2.rds.amazonaws.com -U pega -k pega -t pegadata.sfai_cno_fw_oscrfw_work_contac     -- Debug

./pg_repack -h pd19z0kdjpcdf3w.cwu3l3mfl0vh.us-east-1.rds.amazonaws.com -U pega -k pega -c pegadata -t pegadata.pc_anah_aides_work --dry-run

--after repack table
create table afrepack as ( SELECT * FROM( SELECT schemaname, tblname, bs*tblpages AS real_size,pg_size_pretty(pg_total_relation_size(schemaname||'.'||tblname)) As total_table_size, (tblpages-est_tblpages)*bs AS extra_size, fillfactor, (tblpages-est_tblpages_ff)*bs AS bloat_size, CASE WHEN tblpages - est_tblpages_ff > 0 THEN 100 * (tblpages - est_tblpages_ff)/tblpages::float ELSE 0 END AS bloat_ratio FROM (SELECT ceil( reltuples / ( (bs-page_hdr)/tpl_size ) ) + ceil( toasttuples / 4 ) AS est_tblpages, ceil( reltuples / ( (bs-page_hdr)*fillfactor/(tpl_size*100) ) ) + ceil( toasttuples / 4 ) AS est_tblpages_ff, tblpages, fillfactor, bs, tblid, schemaname, tblname, heappages, toastpages, is_na FROM (SELECT ( 4 + tpl_hdr_size + tpl_data_size + (2*ma) - CASE WHEN tpl_hdr_size%ma = 0 THEN ma ELSE tpl_hdr_size%ma END - CASE WHEN ceil(tpl_data_size)::int%ma = 0 THEN ma ELSE ceil(tpl_data_size)::int%ma END) AS tpl_size, bs - page_hdr AS size_per_block, (heappages + toastpages) AS tblpages, heappages, toastpages, reltuples, toasttuples, bs, page_hdr, tblid, schemaname, tblname, fillfactor, is_na FROM (SELECT tbl.oid AS tblid, ns.nspname AS schemaname, tbl.relname AS tblname, tbl.reltuples, tbl.relpages AS heappages, coalesce(toast.relpages, 0) AS toastpages, coalesce(toast.reltuples, 0) AS toasttuples, coalesce(substring( array_to_string(tbl.reloptions, ' ') FROM '%fillfactor=#"__#"%' FOR '#')::smallint, 100) AS fillfactor, current_setting('block_size')::numeric AS bs, CASE WHEN version()~'mingw32' OR version()~'64-bit|x86_64|ppc64|ia64|amd64' THEN 8 ELSE 4 END AS ma, 24 AS page_hdr, 23 + CASE WHEN MAX(coalesce(null_frac,0)) > 0 THEN ( 7 + count(*) ) / 8 ELSE 0::int END + CASE WHEN tbl.relhasoids THEN 4 ELSE 0 END AS tpl_hdr_size, sum( (1-coalesce(s.null_frac, 0)) * coalesce(s.avg_width, 1024) ) AS tpl_data_size, bool_or(att.atttypid = 'pg_catalog.name'::regtype) AS is_na FROM pg_attribute AS att JOIN pg_class AS tbl ON att.attrelid = tbl.oid JOIN pg_namespace AS ns ON ns.oid = tbl.relnamespace JOIN pg_stats AS s ON s.schemaname=ns.nspname AND s.tablename = tbl.relname AND s.inherited=false AND s.attname=att.attname LEFT JOIN pg_class AS toast ON tbl.reltoastrelid = toast.oid WHERE att.attnum > 0 AND NOT att.attisdropped AND tbl.relkind = 'r' GROUP BY 1,2,3,4,5,6,7,8,9,10, tbl.relhasoids ORDER BY 2,3 ) AS s ) AS s2 ) AS s3 ) AS s4 where schemaname in ('pegadata','customerdata'));

--compare bfrepack and afrepack repack table stats
pega=> \d bfrepack
                    Table "customerdata.bfrepack"
      Column      |       Type       | Collation | Nullable | Default
------------------+------------------+-----------+----------+---------
 schemaname       | name             |           |          |
 tblname          | name             |           |          |
 real_size        | numeric          |           |          |
 total_table_size | text             |           |          |
 extra_size       | double precision |           |          |
 fillfactor       | integer          |           |          |
 bloat_size       | double precision |           |          |
 bloat_ratio      | double precision |           |          |


\copy ( select a.schemaname,a.tblname,a.real_size,b.real_size,a.total_table_size,b.total_table_size,a.extra_size,b.extra_size,a.bloat_size,b.bloat_size,a.bloat_ratio,b.bloat_ratio from bfrepack a join afrepack b on ( a.schemaname = b.schemaname and a.tblname = b.tblname) order by 1,2) to '/local/pega-work/sync-data/CC-146749.csv' csv header;
--drop bfrepack and afrepack repack table
drop table bfrepack;
drop table afrepack;
