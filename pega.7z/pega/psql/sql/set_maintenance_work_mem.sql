show maintenance_work_mem;
set maintenance_work_mem to '2GB';
show maintenance_work_mem;
set maintenance_work_mem to '2GB';
set temp_file_limit to '3GB';