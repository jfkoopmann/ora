SELECT table_schema, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES where lower(table_name)='resolved_rules_pc0';

SELECT table_catalog, table_schema, table_name, column_name, column_default, is_nullable, data_type, character_maximum_length, '1045' go2
  FROM information_schema.columns
 WHERE table_name = 'pr_bd_fw_ccfw_data_fl_ngcc_app'
   AND column_name = 'new_acomment';




select current_timestamp;
ALTER TABLE pegadata.PC_NJJ_CRT_EAMS_WORK DROP COLUMN FIRMID_2;


select concat('alter table ' , table_schema , '.' , table_name , ' drop constraint ', constraint_name, ';') as dropPK
from information_schema.table_constraints
where table_schema = 'customerdata'
and table_name in ('pr_bw_workhub_fhr_data_pr_matr','pr_bw_workhub_fhr_data_pr_allo','pr_bw_workhub_fhr_data_pr_orga','pr_bw_workhub_fhr_data_pr_asse')
and constraint_type = 'PRIMARY KEY';


select t.relname as table_name, i.relname as index_name, a.attname as column_name, a.attnum
from pg_class t, pg_class i, pg_index ix, pg_attribute a
where
    t.oid = ix.indrelid
    and i.oid = ix.indexrelid
    and a.attrelid = t.oid
    and a.attnum = ANY(ix.indkey)
    and t.relkind = 'r'
    and t.relname like 'test%'
order by
    t.relname,
    i.relname, a.attnum;

select relname from pg_class where lower(t.relname) like '%test%';