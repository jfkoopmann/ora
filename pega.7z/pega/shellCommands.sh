find .  -maxdepth 1 -mindepth 1 -type d -name "*internal*"  -exec ls -ld '{}' \;
find .  -maxdepth 1 -mindepth 1 -type d -name "*internal*"  -exec rm -rf '{}' \;
