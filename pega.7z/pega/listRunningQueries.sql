--# list all queries currently running
SELECT * FROM pg_stat_activity;

--# find all queries running longer that some time
SELECT pid, now() - pg_stat_activity.query_start AS duration, query, state FROM pg_stat_activity
WHERE state = 'active' and (now() - pg_stat_activity.query_start) > interval '5 minutes';

--# terminate a pid gracefuly
SELECT pg_cancel_backend(pid);

--# if a hard kill is needed
SELECT pg_terminate_backend(pid);

--# check if pid is still running
SELECT pid, state FROM pg_stat_activity WHERE pid IN (27276,2002,27519,30455);
