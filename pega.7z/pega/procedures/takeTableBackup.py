#-- table backups

#-- 1. from Util node, cat pega-psql to get connection 
cat /usr/local/bin/pega-psql
cat /usr/local/bin/pega-psql | grep psql | awk -F'"' '{print $2}' | sed 's/psql/pg_dump/'

[root@ip-10-96-37-25 ~]# cat /usr/local/bin/pega-psql | grep psql | awk -F'"' '{print $2}' | sed 's/psql/pg_dump/'
/usr/bin/pg_dump -h pdgu9vfzcq9p3e.cpr7jifkq2vy.us-east-1.rds.amazonaws.com -p 5432 -U pega pega

#-- 2. use connection from #1 and cat these lines to the end of it
--data-only --column-inserts 
--schema-only 
-f /local/pega-work/sync-data/CC-135544.sql 
-t 'customerdata.mkt_rmc_agent_lic' -t 'pegadata.pr_data_stream_nodes'

#-- verify file
ls -l /local/pega-work/sync-data/CC-135544.sql 


/usr/bin/pg_dump -h pd1ry1skygut8vx.cbgfwatjux2e.eu-west-2.rds.amazonaws.com -p 5432 -U pega pega -t 'pegadata.pr_nwg_data_connectorMonitorin_bkp_inc201596' -f /local/pega-work/sync-data/pr_nwg_data_connectorMonitorin_bkp_inc201596.sql 
/usr/bin/pg_dump -h pd1ry1skygut8vx.cbgfwatjux2e.eu-west-2.rds.amazonaws.com -p 5432 -U pega pega -t 'pegadata.pr_nwg_cddinlife_data_cddbasel_bkp_inc201596' -f /local/pega-work/sync-data/pr_nwg_cddinlife_data_cddbasel_bkp_inc201596.sql 

pegadata.
pegadata.
/usr/bin/pg_dump -h pd1ry1skygut8vx.cbgfwatjux2e.eu-west-2.rds.amazonaws.com -p 5432 -U pega pega -t 'pegadata.pr_nwg_data_connectormonitorin_bkp_inc201596_2' -f /local/pega-work/sync-data/pr_nwg_data_connectormonitorin_bkp_inc201596_2.sql 
/usr/bin/pg_dump -h pd1ry1skygut8vx.cbgfwatjux2e.eu-west-2.rds.amazonaws.com -p 5432 -U pega pega -t 'pegadata.pr_nwg_cddinlife_data_cddbasel_bkp_inc201596_2' -f /local/pega-work/sync-data/pr_nwg_cddinlife_data_cddbasel_bkp_inc201596_2.sql 


-t 'pega82821830801.pr_assembledclasses' -f /local/pega-work/sync-data/INC214691-pr_assembledclasses.sql

[root@ip-10-123-2-79 ~]# /usr/bin/pg_dump -h pdho5ly6picmjv.col5xoqnuh8h.eu-west-1.rds.amazonaws.com -p 5432 -U pega pega -t 'pega82821830801.pr_assembledclasses' -f /local/pega-work/sync-data/INC214691-pr_assembledclasses.sql
[root@ip-10-123-2-79 ~]# wc -l /local/pega-work/sync-data/INC214691-pr_assembledclasses.sql
122245 /local/pega-work/sync-data/INC214691-pr_assembledclasses.sql
i've produced a dump file for pega82821830801.pr_assembledclasses at /local/pega-work/sync-data/INC214691-pr_assembledclasses.sql


-f /local/pega-work/sync-data/CC-149739.sql -t 'pegadata.common_reference' -t 'pegadata.common_reference_countries' -t 'pegadata.common_reference_currencies' -t 'pegadata.common_reference_merchantcategorycodes' -t 'pegadata.common_reference_specialities' -t 'pegadata.common_reference_states' -t 'pegadata.common_reference_transactionsubtypes' -t 'pegadata.common_reference_lienholders'
