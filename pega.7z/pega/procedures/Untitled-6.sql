
SELECT "PC0"."itemid" AS "ItemID",
         "PC0"."createdatetime" AS "CreateDateTime",
         "PC0"."contactid" AS "ContactId",
         "PC0"."interactiontype" AS "InteractionType",
         "PC0"."ownerid" AS "OwnerID",
         "PC0"."contactdisposition" AS "ContactDisposition",
         "PC0"."pxinsindexedkey" AS "pxInsIndexedKey",
         "PC0"."workstatus" AS "WorkStatus",
         "PC0"."pxobjclass" AS "pxObjClass",
         "PC0"."pzinskey" AS "pzInsKey",
         "PC0"."pxinsindexedclass" AS "pxInsIndexedClass"
FROM pegadata.pca_index_interactions "PC0"
WHERE ("PC0"."contactid" IS NULL
        AND "PC0"."interactiontype" NOT IN (?, ?)
        AND "PC0"."itemid" <> ?)
        AND "PC0"."pxobjclass" = ?
ORDER BY  2 DESC

select count(*) FROM pegadata.pca_index_interactions;
select count(*) FROM pegadata.pca_index_interactions where contactid is null;
select interactiontype, count(*) FROM pegadata.pca_index_interactions where contactid is null group by interactiontype order by count(*);
select itemid, count(*) FROM pegadata.pca_index_interactions where contactid is null group by itemid order by count(*);
select pxobjclass, count(*) FROM pegadata.pca_index_interactions where contactid is null group by pxobjclass order by count(*);

Indexes:
    "pca_index_interactions_pk" PRIMARY KEY, btree (pzinskey)
    "idx_contactid_createdatetime" btree (contactid, createdatetime)
    "pca_index_int_an" btree (accountnumber)
    "pca_index_int_keypurpose" btree (pxindexpurpose, pxinsindexedkey)
    "pca_index_int_oi" btree (ownerid)



pega=> select pxobjclass, count(*) FROM pegadata.pca_index_interactions where contactid is null group by pxobjclass order by count(*);
            pxobjclass            | count
----------------------------------+--------
 Index-PegaCA-ContactInteractions | 663200
(1 row)

pega=> select count(*) FROM pegadata.pca_index_interactions;
  count
----------
 10475253
(1 row)

pega=> select count(*) FROM pegadata.pca_index_interactions where contactid is null;
 count
--------
 663196
(1 row)

pega=> select interactiontype, count(*) FROM pegadata.pca_index_interactions where contactid is null group by interactiontype order by count(*)
pega-> ;
    interactiontype     | count
------------------------+--------
 research               |      1
 Inbound Correspondence |     22
                        |     76
 Web Group Booking      |    317
 Inbound Mail           |   3242
 Social Interaction     |   5750
 Outbound Email         |   9942
 Customer Research      |  18120
 Inbound Phone Call     |  45312
 Inbound Email          | 131318
 Outbound Call          | 137585
 Self Service           | 137702
 Web Self Service       | 173811
(13 rows)

pega=> select itemid, count(*) FROM pegadata.pca_index_interactions where contactid is null group by interactiontype order by count(*);
ERROR:  column "pca_index_interactions.itemid" must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: select itemid, count(*) FROM pegadata.pca_index_interactions...
               ^
pega=> select itemid, count(*) FROM pegadata.pca_index_interactions where contactid is null group by itemid order by count(*);
    itemid     | count
---------------+-------
 IWEB-446855   |     1
 OCALL-88164   |     1
 ICALL-1716644 |     1
 ICR-131032    |     1
 IWEB-801459   |     1


explain analyze
SELECT "PC0"."itemid" AS "ItemID",
         "PC0"."createdatetime" AS "CreateDateTime",
         "PC0"."contactid" AS "ContactId",
         "PC0"."interactiontype" AS "InteractionType",
         "PC0"."ownerid" AS "OwnerID",
         "PC0"."contactdisposition" AS "ContactDisposition",
         "PC0"."pxinsindexedkey" AS "pxInsIndexedKey",
         "PC0"."workstatus" AS "WorkStatus",
         "PC0"."pxobjclass" AS "pxObjClass",
         "PC0"."pzinskey" AS "pzInsKey",
         "PC0"."pxinsindexedclass" AS "pxInsIndexedClass"
FROM pegadata.pca_index_interactions "PC0"
WHERE ("PC0"."contactid" IS NULL
        AND "PC0"."interactiontype" NOT IN ('Inbound Email')
        AND "PC0"."itemid" <> 'IWEB-446855')
        AND "PC0"."pxobjclass" = 'Index-PegaCA-ContactInteractions'
ORDER BY  2 DESC;

CREATE INDEX idx_contactid_pxobjclass_interactiontype ON pegadata.pca_index_interactions USING btree (contactid, pxobjclass, interactiontype,createdatetime);
drop INDEX pegadata.idx_contactid_pxobjclass_interactiontype ;
#-- waiting for bind variables

CREATE INDEX idx_pylabel_pxobjclass ON pegadata.TIP_CS_WORK_FLIGHT USING btree (pylabel,pxobjclass);
drop INDEX pegadata.idx_pylabel_pxobjclass ;