#-- extract DDL for a table

#-- 1. from Util node, cat pega-psql to get connection 
cat /usr/local/bin/pega-psql
cat /usr/local/bin/pega-psql | grep psql | awk -F'"' '{print $2}' | sed 's/psql/pg_dump/'

[root@ip-10-96-37-25 ~]# cat /usr/local/bin/pega-psql | grep psql | awk -F'"' '{print $2}' | sed 's/psql/pg_dump/'
/usr/bin/pg_dump -h pdgu9vfzcq9p3e.cpr7jifkq2vy.us-east-1.rds.amazonaws.com -p 5432 -U pega pega

#-- 2. use connection from #1, -t for table, and --schema-only for DDL generation
/usr/bin/pg_dump -h pd1u1lgnx5n4arm.cpr7jifkq2vy.us-east-1.rds.amazonaws.com -p 5432 -U pega pega -t 'pegadata.toyota_work_qims_lc' --schema-only > pegadata.toyota_work_qims_lc.sql
