# get context.xml

########### Context.xml, server.xml, Config.xml, prweb.xml in 2.1

login to the App server

docker exec -it pega-web bash  --- is to login to pega-web

------------------------------ prweb.xml

cat /usr/local/tomcat/conf/Catalina/localhost/prweb.xml         -- Per Lakshmi, consider prweb for connection string. Containg pega user details

------------------------------ context.xml        -- Will be used only for external DB, rouser

find / -iname context.xml

cat /usr/local/tomcat/conf/context.xml

------------------------------ Server.xml

find / -iname server.xml

cat /usr/local/tomcat/conf/server.xml

------------------------------ prconfig.xml

cat /opt/pega/prweb/WEB-INF/classes/prconfig.xml

------------------------------ web.xml
find / -iname web.xml
/opt/pega/prweb/WEB-INF/web.xml

Sharing web.xml with customer:

create a folder with SR no. in sync-data
copy the file to the new folder inside sync-data
come out of the docker
go to the sync-data folder
connect to your own sftp
and upload the file there and share the public of the file to customer
