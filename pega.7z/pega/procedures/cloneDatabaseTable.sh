#-- clone database table

#-- 1. from Util node, cat pega-psql to get connection 
cat /usr/local/bin/pega-psql
cat /usr/local/bin/pega-psql | grep psql | awk -F'"' '{print $2}' | sed 's/psql/pg_dump/'

[root@ip-10-96-37-25 ~]# cat /usr/local/bin/pega-psql | grep psql | awk -F'"' '{print $2}' | sed 's/psql/pg_dump/'
/usr/bin/pg_dump -h pdgu9vfzcq9p3e.cpr7jifkq2vy.us-east-1.rds.amazonaws.com -p 5432 -U pega pega

#-- 2. use connection from #1, -t for table, and --schema-only for DDL generation
/usr/bin/pg_dump -h pd1u1lgnx5n4arm.cpr7jifkq2vy.us-east-1.rds.amazonaws.com -p 5432 -U pega pega -t 'pegadata.toyota_work_qims_lc' --schema-only > tbl.sql

#-- 3. edit .sql file to modify CREATE and extract indexes/grants
vi tbl.sql

#-- 4. pega-psql --echo-all
pega-psql --echo-all

#-- 5. take timestamp
SELECT CURRENT_TIMESTAMP ;

#-- 6. execute edited .sql file
\i tbl.sql
CREATE TABLE pegadata.toyota_work_qims_lc_archv as select * from pegadata.toyota_work_qims_lc ;
select count(*) from pegadata.toyota_work_qims_lc;
select count(*) from pegadata.toyota_work_qims_lc_archv;
ALTER TABLE pegadata.toyota_work_qims_lc_archv OWNER TO pega;
ALTER TABLE ONLY pegadata.toyota_work_qims_lc_archv ADD CONSTRAINT toyota_work_qims_lc_archv_pf PRIMARY KEY (pzinskey);
CREATE INDEX lcarchvsearch ON pegadata.toyota_work_qims_lc_archv USING btree (documenttrackingnumber, site, suppliercode, tmmcsuppliercode, partnumber, pxcreatedatetime, pystatuswork, qeid);
CREATE INDEX archvpartalerts ON pegadata.toyota_work_qims_lc_archv USING btree (pyresolvedtimestamp, pystatuswork, site);
GRANT SELECT ON TABLE pegadata.toyota_work_qims_lc_archv TO rouser;


#--runtime
pega=> SELECT CURRENT_TIMESTAMP ;
       current_timestamp
-------------------------------
 2021-11-16 18:15:37.476027+00
(1 row)

pega=> CREATE TABLE pegadata.toyota_work_qims_lc_archv as select * from pegadata.toyota_work_qims_lc ;
SELECT 27292
pega=> select count(*) from pegadata.toyota_work_qims_lc;
 count
-------
 27292
(1 row)

pega=> select count(*) from pegadata.toyota_work_qims_lc_archv;
 count
-------
 27292
(1 row)

pega=> truncate table pegadata.toyota_work_qims_lc;
TRUNCATE TABLE

pega=> select count(*) from pegadata.toyota_work_qims_lc_archv;
 count
-------
 27292
(1 row)

pega=> ALTER TABLE pegadata.toyota_work_qims_lc_archv OWNER TO pega;
ALTER TABLE
pega=> ALTER TABLE ONLY pegadata.toyota_work_qims_lc_archv ADD CONSTRAINT toyota_work_qims_lc_archv_pf PRIMARY KEY (pzinskey);
ALTER TABLE
pega=> CREATE INDEX lcarchvsearch ON pegadata.toyota_work_qims_lc_archv USING btree (documenttrackingnumber, site, suppliercode, tmmcsuppliercode, partnumber, pxcreatedatetime, pystatuswork, qeid);
CREATE INDEX
pega=> CREATE INDEX archvpartalerts ON pegadata.toyota_work_qims_lc_archv USING btree (pyresolvedtimestamp, pystatuswork, site);
CREATE INDEX
pega=> GRANT SELECT ON TABLE pegadata.toyota_work_qims_lc_archv TO rouser;
GRANT
