
--#
--# copy table from past PITR instance
--#

1.Launch PITR instance to the timestamp "8AM GMT on 08-Dec, 2021".

2.Extract the missing records using below query from the PITR instance lauched in previous step.

\copy (select * from pegadata.pca_XOS_Cust_CRM_Work where pzInsKeyin ('XOS-CUST-CRM-WORK SURV-1003','XOS-CUST-CRM-WORK SURV-1002','XOS-CUST-CRM-WORK SURV-1006','XOS-CUST-CRM-WORK SURV-6')) to 'output_file.csv' delimiter '|' csv header;

\copy (select * from pegadata.pr_data_adm_factory) to 'output_pr_data_adm_factory.csv' delimiter '|' csv header;
\copy (select * from pegadata.pr_data_adm_factory) to '/local/pega-work/sync-data/output_pr_data_adm_factory_stg2.csv' delimiter '|' csv header;
select count(*) from pegadata.pr_data_adm_factory;
select count(*) from pegadata.pr_data_adm_factory_copy;
create table pegadata.pr_data_adm_factory_copy as (select * from pegadata.pr_data_adm_factory) with no data;

3. Import the data from output_file.csv into table "pca_XOS_Cust_CRM_Work"

\copy pegadata.pca_XOS_Cust_CRM_Work from 'output_file.csv' delimiter '|' csv header;
\copy pegadata.pr_data_adm_factory_copy from 'output_pr_data_adm_factory.csv' delimiter '|' csv header;

After the missing records are imported from PITR instance, delete the PITR instance

UPDATE table1 
SET price=(SELECT price FROM table2 WHERE table1.id=table2.id);


pega=> \d+ pegadata.pr_data_adm_factory
                                         Table "pegadata.pr_data_adm_factory"
       Column        |         Type          | Collation | Nullable | Default | Storage  | Stats target | Description
---------------------+-----------------------+-----------+----------+---------+----------+--------------+-------------
 pymodelpartitionid  | character varying(36) |           | not null |         | extended |              |
 pyconfigpartitionid | character varying(36) |           | not null |         | extended |              |
 pymodelpartition    | text                  |           | not null |         | extended |              |
 pyconfigpartition   | text                  |           | not null |         | extended |              |
 pyformat            | character varying(8)  |           | not null |         | extended |              |
 pyfactory           | text                  |           | not null |         | extended |              |
Indexes:
    "pr_data_adm_factory_pk" PRIMARY KEY, btree (pymodelpartitionid, pyconfigpartitionid)

select count(*) from pegadata.pr_data_adm_factory where pyfactory is not null;
select count(*) from pegadata.pr_data_adm_factory_copy where pyfactory is not null;
select count(*) from pegadata.pr_data_adm_factory_copy where pyfactory is like 'JSON,%null)%';
update 

select count(*)
                     from pegadata.pr_data_adm_factory_copy
                    where pr_data_adm_factory_copy.pymodelpartitionid = '4cd7e1e6-6a44-554d-9ae1-6a4454b43d05'
                      and pr_data_adm_factory_copy.pyconfigpartitionid = '8d245ac2-8034-5244-8f35-77557108b484';

select count(*) from pegadata.pr_data_adm_factory
where exists (select pr_data_adm_factory_copy.pyfactory 
                     from pegadata.pr_data_adm_factory_copy
                    where pr_data_adm_factory.pymodelpartitionid = '4cd7e1e6-6a44-554d-9ae1-6a4454b43d05'
                      and pr_data_adm_factory.pyconfigpartitionid = '8d245ac2-8034-5244-8f35-77557108b484'
                    and   pr_data_adm_factory.pymodelpartitionid = pr_data_adm_factory_copy.pymodelpartitionid 
                      and pr_data_adm_factory.pyconfigpartitionid = pr_data_adm_factory_copy.pyconfigpartitionid);

update pegadata.pr_data_adm_factory 
set pyfactory = (select pr_data_adm_factory_copy.pyfactory 
                     from pegadata.pr_data_adm_factory_copy
                    where pr_data_adm_factory.pymodelpartitionid = '4cd7e1e6-6a44-554d-9ae1-6a4454b43d05'
                      and pr_data_adm_factory.pyconfigpartitionid = '8d245ac2-8034-5244-8f35-77557108b484'
                    and   pr_data_adm_factory.pymodelpartitionid = pr_data_adm_factory_copy.pymodelpartitionid 
                      and pr_data_adm_factory.pyconfigpartitionid = pr_data_adm_factory_copy.pyconfigpartitionid);

update pegadata.pr_data_adm_factory 
set pyfactory = (select pr_data_adm_factory_copy.pyfactory 
                     from pegadata.pr_data_adm_factory_copy
                    where pr_data_adm_factory.pymodelpartitionid = pr_data_adm_factory_copy.pymodelpartitionid 
                      and pr_data_adm_factory.pyconfigpartitionid = pr_data_adm_factory_copy.pyconfigpartitionid);


update pegadata.pr_data_adm_factory 
set pr_data_adm_factory.pyfactory = pr_data_adm_factory_copy.pyfactory 
                     from pegadata.pr_data_adm_factory pdaf
                     inner join pegadata.pr_data_adm_factory_copy
                    on pdaf.pymodelpartitionid = pr_data_adm_factory_copy.pymodelpartitionid 
                      and pdaf.pyconfigpartitionid = pr_data_adm_factory_copy.pyconfigpartitionid;

UPDATE t1
SET t1.c1 = new_value
FROM t2
WHERE t1.c2 = t2.c2;

update pegadata.pr_data_adm_factory 
set pyfactory =  pr_data_adm_factory_copy.pyfactory 
                     from pegadata.pr_data_adm_factory_copy
                    where pr_data_adm_factory.pymodelpartitionid = pr_data_adm_factory_copy.pymodelpartitionid 
                      and pr_data_adm_factory.pyconfigpartitionid = pr_data_adm_factory_copy.pyconfigpartitionid;


update a set c2 = (select b.c2 from b where a.c1 = b.c1);

update a set a.c2 = b.c2 from a pdaf inner join b on pdaf.c1 = b.c1; 

create table a (c1 integer, c2 integer);

UPDATE a
SET a.c1 = t2.c1
FROM a t1 
INNER JOIN b t2 ON t1.id = t2.id;


UPDATE Sales_Import
SET Sales_Import.AccountNumber = RAN.AccountNumber
FROM Sales_Import SI
INNER JOIN RetrieveAccountNumber RAN
ON SI.LeadID = RAN.LeadID;


##-- example 
cat /usr/local/bin/pega-psql
[root@ip-10-100-5-17 ~]# cat .pgpass
pd1h8sw2ggkogqr.ce65gyrdu4jm.eu-west-2.rds.amazonaws.com:5432:pega:pega:cru4lGuCitHOZAbr
[root@ip-10-100-5-17 ~]# cat /usr/local/bin/pega-psql
#!/bin/bash

PSQL="/usr/bin/psql -h pd1h8sw2ggkogqr.ce65gyrdu4jm.eu-west-2.rds.amazonaws.com -p 5432 -U pega pega"

${PSQL} "$@"
[root@ip-10-100-5-17 ~]# /usr/bin/psql -h pd1h8sw2ggkogqr-cc-136898-pitr.ce65gyrdu4jm.eu-west-2.rds.amazonaws.com
Password for user root:
psql: error: FATAL:  password authentication failed for user "root"
FATAL:  no pg_hba.conf entry for host "10.100.5.17", user "root", database "root", SSL off
[root@ip-10-100-5-17 ~]# /usr/bin/psql -h pd1h8sw2ggkogqr-cc-136898-pitr.ce65gyrdu4jm.eu-west-2.rds.amazonaws.com -p 5432 -U pega pega
Password for user pega:
psql (12.5, server 11.5)
SSL connection (protocol: TLSv1.2, cipher: ECDHE-RSA-AES256-GCM-SHA384, bits: 256, compression: off)
Type "help" for help.

pega=> \copy (select * from pegadata.pca_XOS_Cust_CRM_Work where pzInsKeyin ('XOS-CUST-CRM-WORK SURV-1003','XOS-CUST-CRM-WORK SURV-1002','XOS-CUST-CRM-WORK SURV-1006','XOS-CUST-CRM-WORK SURV-6')) to 'output_file.csv' delimiter '|' csv header;
ERROR:  function pzinskeyin(unknown, unknown, unknown, unknown) does not exist
LINE 1: ...elect * from pegadata.pca_XOS_Cust_CRM_Work where pzInsKeyin...
                                                             ^
HINT:  No function matches the given name and argument types. You might need to add explicit type casts.
pega=> \d pegadata.pca_XOS_Cust_CRM_Work
                            Table "pegadata.pca_xos_cust_crm_work"
            Column             |            Type             | Collation | Nullable | Default
-------------------------------+-----------------------------+-----------+----------+---------
 accountnumber                 | character varying(64)       |           |          |
 accountowner                  | character varying(64)       |           |          |
 additionalresearch            | character varying(32)       |           |          |
 authorname                    | character varying(32)       |           |          |
 businessunit                  | character varying(64)       |           |          |
 cabenchmarkduration           | numeric(18,9)               |           |          |
 campaignname                  | character varying(64)       |           |          |
 caparentid                    | character varying(255)      |           |          |
 category                      | character varying(32)       |           |          |
 city                          | character varying(256)      |           |          |
 comments                      | character varying(256)      |           |          |
 contactdisposition            | character varying(50)       |           |          |
 contactid                     | character varying(64)       |           |          |
 contactname                   | character varying(32)       |           |          |
 contenttype                   | character varying(255)      |           |          |
 cpmcustomerdisplayname        | character varying(32)       |           |          |
 emailcaseid                   | character varying(32)       |           |          |
 employeeid                    | character varying(256)      |           |          |
 expectedclose                 | character varying(8)        |           |          |
 firstname                     | character varying(256)      |           |          |
 inquirydate                   | character varying(10)       |           |          |
 interactiongoal               | character varying(32)       |           |          |
 interactiontime               | numeric(19,2)               |           |          |
 interactiontype               | character varying(256)      |           |          |
 isescalatedcase               | character varying(5)        |           |          |
 isitemsopen                   | character varying(10)       |           |          |
 isrelatedtopriorinquiry       | character varying(5)        |           |          |
 istransferredin               | numeric(18,0)               |           |          |
 istransferredout              | numeric(18,0)               |           |          |
 kmupdatesuggestions           | character varying(32)       |           |          |
 knowledgecategory             | character varying(64)       |           |          |
 language                      | character varying(30)       |           |          |
 lastname                      | character varying(256)      |           |          |
 middlename                    | character varying(256)      |           |          |
 name                          | character varying(256)      |           |          |
 netpromotercategory           | character varying(12)       |           |          |
 netpromoterscore              | numeric(19,2)               |           |          |
 noofitemscreated              | numeric(18,0)               |           |          |
 overallrating                 | character varying(32)       |           |          |
 overalltimelimit              | character varying(32)       |           |          |
 pxcommitdatetime              | timestamp without time zone |           |          |
 pxcoveredcount                | numeric(18,0)               |           |          |
 pxcoveredcountopen            | numeric(18,0)               |           |          |
 pxcoveredcountunsatisfied     | numeric(18,0)               |           |          |
 pxcoverinskey                 | character varying(255)      |           |          |
 pxcreatedatetime              | timestamp without time zone |           |          |
 pxcreateoperator              | character varying(128)      |           |          |
 pxcreateopname                | character varying(128)      |           |          |
 pxcreatesystemid              | character varying(32)       |           |          |
 pxflowcount                   | numeric(18,0)               |           |          |
 pxinsname                     | character varying(128)      |           |          |
 pxmatchscore                  | numeric(18,9)               |           |          |
 pxobjclass                    | character varying(96)       |           |          |
 pxsavedatetime                | timestamp without time zone |           |          |
 pxupdatedatetime              | timestamp without time zone |           |          |
 pxupdateoperator              | character varying(128)      |           |          |
 pxupdateopname                | character varying(128)      |           |          |
 pxupdatesystemid              | character varying(32)       |           |          |
 pxurgencywork                 | numeric(18,0)               |           |          |
 pyacktimestamp                | timestamp without time zone |           |          |
 pyagefromdate                 | timestamp without time zone |           |          |
 pychargeamount                | numeric(18,0)               |           |          |
 pychargeto                    | character varying(64)       |           |          |
 pycontactchannel              | character varying(64)       |           |          |
 pycontacttype                 | character varying(64)       |           |          |
 pycuslevel                    | character varying(32)       |           |          |
 pycustomer                    | character varying(128)      |           |          |
 pycustomerenterprise          | character varying(32)       |           |          |
 pycustomername                | character varying(64)       |           |          |
 pycustomerorg                 | character varying(32)       |           |          |
 pycustomersatisfiedtimestamp  | timestamp without time zone |           |          |
 pydescription                 | character varying(255)      |           |          |
 pyeffortactual                | numeric(18,0)               |           |          |
 pyeffortestimate              | numeric(18,0)               |           |          |
 pyeffortestimatetimestamp     | timestamp without time zone |           |          |
 pyelapsedcustomerack          | numeric(18,0)               |           |          |
 pyelapsedcustomerunsatisfied  | numeric(18,0)               |           |          |
 pyelapsedpastdeadline         | numeric(18,0)               |           |          |
 pyelapsedpastgoal             | numeric(18,0)               |           |          |
 pyelapsedstatusnew            | numeric(18,0)               |           |          |
 pyelapsedstatusopen           | numeric(18,0)               |           |          |
 pyelapsedstatuspending        | numeric(18,0)               |           |          |
 pyeventid                     | character varying(255)      |           |          |
 pyfoldertype                  | character varying(32)       |           |          |
 pyid                          | character varying(32)       |           |          |
 pyinstructions                | character varying(255)      |           |          |
 pylabel                       | character varying(64)       |           |          |
 pyorigdivision                | character varying(32)       |           |          |
 pyorigorg                     | character varying(32)       |           |          |
 pyorigorgunit                 | character varying(32)       |           |          |
 pyoriguserdivision            | character varying(32)       |           |          |
 pyoriguserid                  | character varying(128)      |           |          |
 pyoriguserworkgroup           | character varying(64)       |           |          |
 pyownerdivision               | character varying(32)       |           |          |
 pyownerorg                    | character varying(32)       |           |          |
 pyownerorgunit                | character varying(32)       |           |          |
 pyprimarycontact              | character varying(64)       |           |          |
 pyproblemreason               | character varying(64)       |           |          |
 pyproblemsource               | character varying(64)       |           |          |
 pyproblemtype                 | character varying(64)       |           |          |
 pyreopencount                 | numeric(18,0)               |           |          |
 pyreopentimestamp             | timestamp without time zone |           |          |
 pyresolutioncomplexity        | character varying(8)        |           |          |
 pyresolutioncost              | numeric(18,0)               |           |          |
 pyresolveddivision            | character varying(32)       |           |          |
 pyresolvedorg                 | character varying(32)       |           |          |
 pyresolvedorgunit             | character varying(32)       |           |          |
 pyresolvedtime                | character varying(32)       |           |          |
 pyresolvedtimestamp           | timestamp without time zone |           |          |
 pyresolveduserid              | character varying(128)      |           |          |
 pyresolveduserworkgroup       | character varying(64)       |           |          |
 pyrootcause                   | character varying(64)       |           |          |
 pysladeadline                 | timestamp without time zone |           |          |
 pyslagoal                     | timestamp without time zone |           |          |
 pyslaname                     | character varying(32)       |           |          |
 pystatuscustomersat           | character varying(32)       |           |          |
 pystatuswork                  | character varying(32)       |           |          |
 pyworklistdate1               | character varying(8)        |           |          |
 pyworklistdatetime1           | timestamp without time zone |           |          |
 pyworklistdatetime2           | timestamp without time zone |           |          |
 pyworklistdecimal1            | numeric(18,0)               |           |          |
 pyworklistdecimal2            | numeric(18,0)               |           |          |
 pyworklistinteger1            | numeric(18,0)               |           |          |
 pyworklisttext1               | character varying(128)      |           |          |
 pyworklisttext2               | character varying(128)      |           |          |
 pyworklisttext3               | character varying(128)      |           |          |
 pzinskey                      | character varying(255)      |           | not null |
 pzpvstream                    | bytea                       |           |          |
 qualityreviewcaseid           | character varying(32)       |           |          |
 queueid                       | character varying(32)       |           |          |
 queuename                     | character varying(32)       |           |          |
 rdeday                        | character varying(30)       |           |          |
 rdemonth                      | character varying(30)       |           |          |
 rdequarter                    | character varying(30)       |           |          |
 rdeweek                       | character varying(30)       |           |          |
 rdeyear                       | character varying(30)       |           |          |
 reason                        | character varying(32)       |           |          |
 reasonforinteraction          | character varying(50)       |           |          |
 rejectreason                  | character varying(50)       |           |          |
 savingsamount                 | numeric(10,0)               |           |          |
 selectedtopic                 | character varying(32)       |           |          |
 selectiontype                 | character varying(32)       |           |          |
 selectreason                  | character varying(32)       |           |          |
 sentimentvalue                | numeric(18,0)               |           |          |
 sessioncode                   | character varying(32)       |           |          |
 socialmediasource             | character varying(64)       |           |          |
 stpautocreate                 | character varying(5)        |           |          |
 timesavings                   | numeric(10,0)               |           |          |
 topic                         | character varying(255)      |           |          |
 totalscore                    | numeric(18,0)               |           |          |
 totalvalue                    | numeric(18,0)               |           |          |
 updatekmcontent               | character varying(32)       |           |          |
 waittime                      | numeric(18,3)               |           |          |
 templatecategory              | character varying(32)       |           |          |
pega=> \copy (select * from pegadata.pca_XOS_Cust_CRM_Work where pzInsKey in ('XOS-CUST-CRM-WORK SURV-1003','XOS-CUST-CRM-WORK SURV-1002','XOS-CUST-CRM-WORK SURV-1006','XOS-CUST-CRM-WORK SURV-6')) to 'output_file.csv' delimiter '|' csv header;
COPY 4
pega=> \q
[root@ip-10-100-5-17 ~]# ls -latr
total 220
-rw-r--r--  1 root root    129 Jan 15  2011 .tcshrc
-rw-r--r--  1 root root    100 Jan 15  2011 .cshrc
-rw-r--r--  1 root root    176 Jan 15  2011 .bashrc
-rw-r--r--  1 root root    176 Jan 15  2011 .bash_profile
-rw-r--r--  1 root root     18 Jan 15  2011 .bash_logout
drwx------  2 root root   4096 Jul 29 09:22 .ssh
drwxr-xr-x  2 root root   4096 Jul 29 09:22 oracle_client
drwx------  3 root root   4096 Jul 29 09:33 .cache
drwx------  3 root root   4096 Jul 29 09:33 .ansible
drwx------  2 root root   4096 Nov 27 17:14 .docker
-rw-r--r--  1 root root    267 Nov 27 17:14 .wget-hsts
-rw-------  1 root root   1024 Nov 27 17:15 .rnd
-rw-------  1 root root     89 Nov 27 17:15 .pgpass
dr-xr-xr-x 27 root root   4096 Dec  6 06:33 ..
-rw-r--r--  1 root root 159587 Dec  9 17:01 output_file.csv
-rw-------  1 root root    510 Dec  9 17:01 .psql_history
dr-xr-x---  7 root root   4096 Dec  9 17:01 .
[root@ip-10-100-5-17 ~]# pega-psql
psql (12.5, server 11.5)
SSL connection (protocol: TLSv1.2, cipher: ECDHE-RSA-AES256-GCM-SHA384, bits: 256, compression: off)
Type "help" for help.

pega=> \copy pegadata.pca_XOS_Cust_CRM_Work from 'output_file.csv' delimiter '|' csv header;
COPY 4

