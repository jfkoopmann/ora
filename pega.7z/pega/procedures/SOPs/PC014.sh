#-- PC014 : Production : <env> : elk-server : System Disk Usage high on elk-server - /var/lib/docker : ELK-i-01892ce92819941f9

On AL1, the docker container log files are /local/docker/containers/*/*.log
On AL2, the docker container log files have been changed to /var/lib/docker/*/containers/*/*.log

The log rotation configuration file /etc/logrotate.d/docker has not been updated with the new location of log files.
When there are several GB files with /var/lib/docker/*/containers/*/*-json.log, the /var/lib/docker file system will be 100%.

#-- find location of -json.log file
[ec2-user@ip-10-123-10-15 ~]$ sudo su -
Last login: Fri Mar  4 17:37:44 UTC 2022 on pts/0
[root@ip-10-123-10-15 ~]# cd /var/lib/docker/399499.399499/containers/
[root@ip-10-123-10-15 containers]# ls -l
total 0
drwx--x--- 4 root 399499 213 Feb 26 01:30 14edecb9ec15e3cfbe7a69c667d6b93050a131d5e940c5c2045d4049f62b5d5c
drwx--x--- 4 root 399499 213 Feb 26 01:34 6df40c39c31ce66718e66411d2c839b50e15882d212cf9e7075b9fe1a9774479
drwx--x--- 4 root 399499 237 Feb 26 01:33 75e0b8a01ce693d04f8d0e8789b03e29dd4ea5502414f339825d1ed56da9e9b5
drwx--x--- 4 root 399499 213 Feb 26 01:31 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52
drwx--x--- 4 root 399499 213 Feb 26 01:33 acca3f58d95925d4521c28b8ba4b8e954b71a2953540f8529773dc910b287de9
drwx--x--- 4 root 399499 213 Feb 26 01:34 d2f907f9479bd0f2f541cd31bc5644442bd8c9ac5aaa0b2fed29bee35485f9bf
[root@ip-10-123-10-15 containers]# du -sh *
28K     14edecb9ec15e3cfbe7a69c667d6b93050a131d5e940c5c2045d4049f62b5d5c
24K     6df40c39c31ce66718e66411d2c839b50e15882d212cf9e7075b9fe1a9774479
58M     75e0b8a01ce693d04f8d0e8789b03e29dd4ea5502414f339825d1ed56da9e9b5
11G     7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52
24K     acca3f58d95925d4521c28b8ba4b8e954b71a2953540f8529773dc910b287de9
24K     d2f907f9479bd0f2f541cd31bc5644442bd8c9ac5aaa0b2fed29bee35485f9bf
[root@ip-10-123-10-15 containers]# cd 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52/
[root@ip-10-123-10-15 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52]# ls -latr
total 10912912
drwx------ 2 root   root             6 Feb 26 01:31 checkpoints
-rw-r--r-- 1 399499 399499         173 Feb 26 01:31 resolv.conf
-rw-r--r-- 1 399499 399499         126 Feb 26 01:31 hosts
-rw-r--r-- 1 399499 399499          43 Feb 26 01:31 hostname
drwx--x--- 3 root   399499          17 Feb 26 01:31 mounts
-rw-r--r-- 1 root   root          1500 Feb 26 01:31 hostconfig.json
-rw------- 1 root   root          3854 Feb 26 01:31 config.v2.json
drwx--x--- 4 root   399499         213 Feb 26 01:31 .
drwx--x--- 8 root   399499        4096 Feb 26 01:34 ..
-rw-r----- 1 root   root   11174793216 Mar  4 18:16 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52-json.log
[root@ip-10-123-10-15 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52]# df -k .
Filesystem                        1K-blocks     Used Available Use% Mounted on
/dev/mapper/pc_base_vg0-docker_lv  14665728 14665708        20 100% /var/lib/docker

#-- truncate the -json.log file (logrotate will not work as near 0% on disk)
[root@ip-10-123-10-15 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52]# echo "" > 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52-json.log
[root@ip-10-123-10-15 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52]# df -k .
Filesystem                        1K-blocks    Used Available Use% Mounted on
/dev/mapper/pc_base_vg0-docker_lv  14665728 3757004  10908724  26% /var/lib/docker


#-- Need to update the log rotation configuration file /etc/logrotate.d/docker for the change.
vi /etc/logrotate.d/docker

/var/lib/docker/*/containers/*/*.log {
    missingok
    notifempty
    size 10M
    compress
    copytruncate
    rotate 5
    dateext
    dateformat -%Y%m%d-%s
}

#-- Please fix the cron timings to 5 minutes instead of 15 minutes
crontab -e 

[root@ip-10-123-10-15 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52]# crontab -l
#Ansible: curate elasticsearch
@daily /usr/local/bin/curator delete indices --time-unit days --older-than 30 --timestring '\%Y.\%m.\%d'
#Ansible: log truncate script
0 1 * * * /usr/local/bin/log-archive.py >/dev/null 2>&1
#Ansible: execute logrotate for docker
*/5 * * * * /usr/sbin/logrotate /etc/logrotate.d/docker >/dev/null 2>&1
[root@ip-10-123-10-15 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52]#

#-- validate logrotate is working
#-- wait and watch / monitor for 6 logrotates to ensure enough space to keep 5 log files
[root@ip-10-123-10-15 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52]# ls -latr *-json*
-rw-r----- 1 root root   5268973 Mar  4 18:20 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52-json.log-20220304-1646418002.gz
-rw-r----- 1 root root 250422996 Mar  4 18:20 7f159d5aee5b09b86797be59fd8c245066527b281ede94cadcdce491a49c7c52-json.log
