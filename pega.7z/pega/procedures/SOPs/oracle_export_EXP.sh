#-- oracle export
#--
[root@ip-192-168-128-69 ~]# which pega-sqlplus
/usr/local/bin/pega-sqlplus
[root@ip-192-168-128-69 ~]# cat /usr/local/bin/pega-sqlplus
#!/bin/bash

export LD_LIBRARY_PATH=/usr/lib/oracle/12.2/client64/lib/:$LD_LIBRARY_PATH

SQLPLUS="/usr/lib/oracle/12.2/client64/bin/sqlplus pega/k75ast4SPurl6isw@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=po43bwwsstvlja.cpr7jifkq2vy.us-east-1.rds.amazonaws.com)(PORT=1521))(CONNECT_DATA=(SID=pega)))"

${SQLPLUS} ""$@""


export LD_LIBRARY_PATH=/usr/lib/oracle/12.2/client64/lib/:$LD_LIBRARY_PATH

[root@ip-192-168-128-69 ~]# EXP="/usr/lib/oracle/12.2/client64/bin/exp pega/k75ast4SPurl6isw@\(DESCRIPTION\=\(ADDRESS\=\(PROTOCOL\=TCP\)\(HOST\=po43bwwsstvlja.cpr7jifkq2vy.us-east-1.rds.amazonaws.com\)\(POR
T\=1521\)\)\(CONNECT_DATA\=\(SID\=pega\)\)\) tables=pegadata.PR_CEP_EVENTS_QUEUE file=CC-140914.dmp"
[root@ip-192-168-128-69 ~]# $EXPIT
[root@ip-192-168-128-69 ~]# $EXP

Export: Release 12.2.0.1.0 - Production on Wed Feb 2 21:18:22 2022

Copyright (c) 1982, 2017, Oracle and/or its affiliates.  All rights reserved.


Connected to: Oracle Database 19c Standard Edition 2 Release 19.0.0.0.0 - Production
Export done in US7ASCII character set and AL16UTF16 NCHAR character set
server uses AL32UTF8 character set (possible charset conversion)

About to export specified tables via Conventional Path ...
Current user changed to PEGADATA
. . exporting table            PR_CEP_EVENTS_QUEUE       2361 rows exported
EXP-00091: Exporting questionable statistics.
EXP-00091: Exporting questionable statistics.
EXP-00091: Exporting questionable statistics.
EXP-00091: Exporting questionable statistics.
Export terminated successfully with warnings.
