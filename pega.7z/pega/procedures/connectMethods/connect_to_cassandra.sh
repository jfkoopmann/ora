
#-- connect to cassandra
1. login from wintermute using CMDB path
wintermute@ ~/jfktst/t3 () $
| => ec2-login.py -c /ROOT/PEGACLOUD/BAXCH/CR55655/BXHSA/eu-central-1/PROD/prod1

2. select a PegaDDSTier node
17  PegaDDSTier          i-0b8a0dfb4774888da  running  no-IP           198.18.8.122   us-east-1a  2022-01-11 14:28:49+00:00
*** Please input the instance number 0-35, r to refresh or q to exit:  17
[2022-01-25 18:02:50,035] [WARNING] [986] NAT Gateway is used for this environment sirsxm-cepl-prod1-mirror
[2022-01-25 18:02:50,035] [WARNING] [766] Unable to run ssh command with public_IP: no-IP & ssh_key: SIRSXM-CR50385-key.pem
[2022-01-25 18:02:50,054] [INFO] [900] check aws ssm connection to sirsxm-cepl-prod1-mirror PegaDDSTier i-0b8a0dfb4774888da (2.21-15)
...
[2022-01-25 18:02:52,198] [INFO] [830] check aws ssm connection return with state: Success
[2022-01-25 18:02:52,200] [INFO] [905] aws ssm to sirsxm-cepl-prod1-mirror PegaDDSTier i-0b8a0dfb4774888da (2.21-15) with IP: no-IP (198.18.8.122)
[2022-01-25 18:02:52,201] [INFO] [906] ssm command: aws ssm start-session --target i-0b8a0dfb4774888da --region us-east-1 --profile default
Warning: Permanently added 'i-0b8a0dfb4774888da' (ECDSA) to the list of known hosts.
Last login: Thu Jul 29 11:04:08 2021 from ec2-23-20-231-83.compute-1.amazonaws.com

       __|  __|_  )
       _|  (     /   Amazon Linux AMI
      ___|\___|___|

https://aws.amazon.com/amazon-linux-ami/2018.03-release-notes/
17 package(s) needed for security, out of 21 available
Run "sudo yum update" to apply all updates.
[ec2-user@ip-198-18-8-122 ~]$


3. sudo to root
[ec2-user@ip-198-18-8-122 ~]$ sudo su -

4. locate cqlsh 
[root@ip-198-18-8-122 ~]# locate cqlsh
/local/docker/overlay2/cc1818b87f2bddb20213d79416cb6bff615ce005cc584234f1b2ce9848bd451b/diff/usr/local/tomcat/cassandra/bin/cqlsh

5. connect to cassandra
[root@ip-198-18-8-122 ~]# /local/docker/overlay2/cc1818b87f2bddb20213d79416cb6bff615ce005cc584234f1b2ce9848bd451b/diff/usr/local/tomcat/cassandra/bin/cqlsh 198.18.8.122 9042 -udnode_ext
Password:
Connected to prpc at 198.18.8.122:9042.
[cqlsh 5.0.1 | Cassandra 2.1.20 | CQL spec 3.2.1 | Native protocol v3]
Use HELP for help.
dnode_ext@cqlsh>

6. perform activity
dnode_ext@cqlsh> select count(*) from adm.adm_scoringmodel;

 count
-------
  4018

(1 rows)




[root@ip-172-16-1-6 pega-cassandra-data]# df -k .
Filesystem     1K-blocks      Used Available Use% Mounted on
/dev/nvme2n1   206293688 176657700  20161552  90% /local/pega-cassandra-data
[root@ip-172-16-1-6 pega-cassandra-data]# du -sh *
6.7G    commitlog
162G    data
16K     lost+found
4.0K    prpc_node_id
102M    saved_caches



[root@ip-172-16-1-6 data]# history
    1  df -k
    2  cd /local/pega-cassandra-data
    3  ls -latr
    4  du -sh *
    5  df -k .
    6  du -sh *
    7  df -k .
    8  ls -l
    9  cd data
   10  ls
   11  ls -l
   12  cd data
   13  ls -l
   14  cd ..
   15  du -sh *
   16  cd data
   17  df -k .
   18  locate cqlsh
   19  /local/docker/overlay2/cbd635eccd67fa8ffdda5f322c903e68c63816e2a7bfe4bc886b69859e1eb06c/diff/usr/local/tomcat/cassandra/bin/cqlsh ip-172-16-1-6 9042 -u dnode_ext
   20  which nodetool
   21  /local/docker/overlay2/cbd635eccd67fa8ffdda5f322c903e68c63816e2a7bfe4bc886b69859e1eb06c/diff/usr/local/tomcat/cassandra/bin/cqlsh ip-172-16-1-6 9042 -u dnode_ext
   22  locate nodetool
   23  /local/docker/overlay2/6b2aaefba9f05771dd69a3ebdf3392dbff9ff78de40a3023b9412a44fa90a8a0/diff/usr/local/bin/pega-nodetool
   24  /local/docker/overlay2/6b2aaefba9f05771dd69a3ebdf3392dbff9ff78de40a3023b9412a44fa90a8a0/diff/usr/local/bin/pega-nodetool status
   25  df -k .
   26  /local/docker/overlay2/6b2aaefba9f05771dd69a3ebdf3392dbff9ff78de40a3023b9412a44fa90a8a0/diff/usr/local/bin/pega-nodetool cfstats
   27  /local/docker/overlay2/6b2aaefba9f05771dd69a3ebdf3392dbff9ff78de40a3023b9412a44fa90a8a0/diff/usr/local/bin/pega-nodetool cfstats | grep -i "table\|space"
   28  pwd
   29  /local/docker/overlay2/6b2aaefba9f05771dd69a3ebdf3392dbff9ff78de40a3023b9412a44fa90a8a0/diff/usr/local/bin/pega-nodetool cfstats | grep -i "table:\|space used (live)"
   30  /local/docker/overlay2/6b2aaefba9f05771dd69a3ebdf3392dbff9ff78de40a3023b9412a44fa90a8a0/diff/usr/local/bin/pega-nodetool cfstats | grep -i "table:\|space used (live)" > 1
   31  view 1
   32  du -sh * | grep G
   33  history


[root@ip-172-16-1-6 data]# du -sh * | grep G
1.4G    customerdds_40462b482fc77e1f6cc3ff410a31b4e2-c2615d80610e11ecb7850fee08a81fb3
61G     customerdds_6446dcc8a20ea167226092b63af53f97-5846b730c3d211ebb73fdb46b189cb5c
12G     es_1291363649_adaptive_cst-4249f4c0559211e988e9db46b189cb5c
1.6G    pxdecisionresults_pega_decisionengine_ab5de04587-41e9ac50559211e988e9db46b189cb5c
52G     recordswitholdp_6f20635b78a952bbef255cf5ad6a994f-c3a2b2401b6111ecb89521dda814f832