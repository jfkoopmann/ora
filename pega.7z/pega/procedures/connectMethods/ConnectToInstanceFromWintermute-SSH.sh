--# connect to instance from wintermute
wintermute@ ~ () $
| => ssh -i ~/Provisioning-Engine/CustomerKeys/IECUSA-CR51331-key.pem ec2-user@54.146.114.87