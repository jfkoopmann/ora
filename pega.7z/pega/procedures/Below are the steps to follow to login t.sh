Below are the steps to follow to login to the RDS PSQL prompt in cloudk .

1)Identify the cluster name in cloud k GOC at resources for the environment
74af56bb-ba5d-452c-a1b6-ae3d9e12730c
cluster011

2)Login to fnx winterfell and sudo to wintermute

3)change the directory to kubeconfig
cd kubeconfig

4) list config files for each client
--- will show the config files for each client and will have to identify them. Use this with -kubeconfig parameter in the commands
ls -ltr  
ls -latr *cluster011*
-rwxrwxrwx 1 wintermute wintermute      1910 Jul 15 13:28 cluster011_eu-west-3_UGIEIR


4)list the namespace with below command on the cluster 

5)kubectl get ns --kubeconfig=cluster004_us-east-1_charter
List namespace : it should one with the same name as the env name
kubectl get ns --kubeconfig=cluster011_eu-west-3_UGIEIR
ugieir-pegasu-dt1               Active   168d


6)list the pods for the environment (sometimes .yaml file, sometimes no extention)
kubectl get pods -n ugieir-pegasu-dt1 --kubeconfig=cluster011_eu-west-3_UGIEIR

List pods :  should list one for dbtools
kubectl get pods -n ugieir-pegasu-dt1 --kubeconfig=cluster011_eu-west-3_UGIEIR
NAME                                READY   STATUS    RESTARTS   AGE
db-tools-service-76cd655d5f-vf9h6   2/2     Running   0          6d10h


8)Login to db-toos-service pod with the below command

9)kubectl exec -ti db-tools-service-7d8d958899-5f6rj -n lcbo-lcbecm-prod1 -c pega-web-tomcat --kubeconfig=cluster009_ca-central-1.yaml -- bash
Use this command to login with bash. provide the pod, namespace, config file
kubectl exec -ti db-tools-service-76cd655d5f-vf9h6 -n ugieir-pegasu-dt1 -c pega-web-tomcat --kubeconfig=cluster011_eu-west-3_UGIEIR -- bash

10)Type in as psql which will login to the RDS psql prompt.
